#pragma once
#include <vector>
#include <glm/glm.hpp>

namespace SectorG {

    struct Vertex {
        glm::vec3 Position;
        glm::vec3 Normal;
        glm::vec2 UV;
    };

    class Mesh {
    public:
        Mesh() = default;
        Mesh(const std::vector<Vertex>& vertices,
             const std::vector<unsigned int>& indices);
        ~Mesh();

        Mesh(const Mesh&)            = delete;
        Mesh& operator=(const Mesh&) = delete;

        Mesh(Mesh&& other) noexcept;
        Mesh& operator=(Mesh&& other) noexcept;

        void Draw() const;

        static Mesh CreateCube();
        static Mesh CreateFloor(float size);
        static Mesh CreateTerrain(float size, int resolution);
        static Mesh CreateWaterPlane(float size, int resolution, float height);

    private:
        void Upload(const std::vector<Vertex>& vertices,
                    const std::vector<unsigned int>& indices);

        unsigned int m_VAO = 0;
        unsigned int m_VBO = 0;
        unsigned int m_EBO = 0;
        unsigned int m_IndexCount = 0;
    };

}