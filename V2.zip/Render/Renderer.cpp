#include "Render/Renderer.h"
#include "Utils/Log.h"

#define GLEW_STATIC
#include <GL/glew.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <stb_image.h>
#include <string>
#include <vector>
#include <cmath>

namespace SectorG {

    // ============================================================
    // MAIN SHADERS
    // ============================================================

    static const char* s_VertexShaderSrc = R"(
        #version 330 core
        layout (location = 0) in vec3 aPos;
        layout (location = 1) in vec3 aNormal;
        layout (location = 2) in vec2 aUV;

        uniform mat4 uModel;
        uniform mat4 uView;
        uniform mat4 uProjection;

        out vec3 vFragPos;
        out vec3 vNormal;
        out vec2 vUV;

        void main() {
            vFragPos = vec3(uModel * vec4(aPos, 1.0));
            vNormal  = mat3(transpose(inverse(uModel))) * aNormal;
            vUV      = aUV;
            gl_Position = uProjection * uView * vec4(vFragPos, 1.0);
        }
    )";

    static const char* s_FragmentShaderSrc = R"(
        #version 330 core
        in vec3 vFragPos;
        in vec3 vNormal;
        in vec2 vUV;

        out vec4 FragColor;

        #define MAX_LIGHTS 8
        #define MAX_SHADOW_LIGHTS 2

        struct Light {
            int   type;
            vec3  position;
            vec3  direction;
            vec3  color;
            float intensity;
            float range;
            float cosInner;
            float cosOuter;
            int   shadowIndex;
        };

        uniform Light uLights[MAX_LIGHTS];
        uniform int   uLightCount;

        uniform sampler2D uShadowMaps[MAX_SHADOW_LIGHTS];
        uniform mat4      uLightSpaceMatrices[MAX_SHADOW_LIGHTS];

        uniform vec3 uViewPos;
        uniform vec3 uObjectColor;
        uniform sampler2D uTexture;

        uniform vec3  uFogColor;
        uniform float uFogDensity;

        float PCF(sampler2D shadowMap, vec4 fragPosLightSpace, vec3 norm, vec3 lightDir) {
            vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
            projCoords = projCoords * 0.5 + 0.5;
            if (projCoords.z > 1.0) return 0.0;
            float bias = max(0.05 * (1.0 - dot(norm, lightDir)), 0.005);
            float shadow = 0.0;
            vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
            for (int x = -1; x <= 1; ++x)
                for (int y = -1; y <= 1; ++y) {
                    float d = texture(shadowMap, projCoords.xy + vec2(x, y) * texelSize).r;
                    shadow += (projCoords.z - bias > d) ? 1.0 : 0.0;
                }
            return shadow / 9.0;
        }

        vec3 CalcPointLight(Light light, vec3 norm, vec3 viewDir, vec3 fragPos) {
            vec3  lightDir = normalize(light.position - fragPos);
            float diff     = max(dot(norm, lightDir), 0.0);
            vec3  halfDir  = normalize(lightDir + viewDir);
            float spec     = pow(max(dot(norm, halfDir), 0.0), 64);
            float dist        = length(light.position - fragPos);
            float attenuation = clamp(1.0 - (dist * dist) / (light.range * light.range), 0.0, 1.0);
            attenuation = attenuation * attenuation;
            vec3 color = light.color * light.intensity;
            return (0.1 + diff * 0.8 + spec * 0.5) * color * attenuation;
        }

        vec3 CalcDirLight(Light light, vec3 norm, vec3 viewDir, float shadow) {
            vec3  lightDir = normalize(-light.direction);
            float diff     = max(dot(norm, lightDir), 0.0);
            vec3  halfDir  = normalize(lightDir + viewDir);
            float spec     = pow(max(dot(norm, halfDir), 0.0), 64);
            vec3 color = light.color * light.intensity;
            return 0.1 * color + (1.0 - shadow) * (diff * 0.8 * color + spec * 0.5 * color);
        }

        vec3 CalcSpotLight(Light light, vec3 norm, vec3 viewDir, vec3 fragPos, float shadow) {
            vec3  lightDir = normalize(light.position - fragPos);
            float diff     = max(dot(norm, lightDir), 0.0);
            vec3  halfDir  = normalize(lightDir + viewDir);
            float spec     = pow(max(dot(norm, halfDir), 0.0), 64);
            float dist        = length(light.position - fragPos);
            float attenuation = clamp(1.0 - (dist * dist) / (light.range * light.range), 0.0, 1.0);
            attenuation = attenuation * attenuation;
            float theta = dot(lightDir, normalize(-light.direction));
            float epsilon = light.cosInner - light.cosOuter;
            float spotFactor = clamp((theta - light.cosOuter) / epsilon, 0.0, 1.0);
            vec3 color = light.color * light.intensity;
            return (0.1 * color + (1.0 - shadow) * (diff * 0.8 * color + spec * 0.5 * color)) * attenuation * spotFactor;
        }

        void main() {
            vec3 norm    = normalize(vNormal);
            vec3 viewDir = normalize(uViewPos - vFragPos);
            vec3 lighting = vec3(0.0);

            for (int i = 0; i < uLightCount; ++i) {
                Light l = uLights[i];
                float shadow = 0.0;
                if (l.shadowIndex >= 0) {
                    vec4 fragPosLS = uLightSpaceMatrices[l.shadowIndex] * vec4(vFragPos, 1.0);
                    vec3 lightDir;
                    if (l.type == 1) lightDir = normalize(-l.direction);
                    else             lightDir = normalize(l.position - vFragPos);
                    shadow = PCF(uShadowMaps[l.shadowIndex], fragPosLS, norm, lightDir);
                }
                if (l.type == 0)      lighting += CalcPointLight(l, norm, viewDir, vFragPos);
                else if (l.type == 1) lighting += CalcDirLight(l, norm, viewDir, shadow);
                else if (l.type == 2) lighting += CalcSpotLight(l, norm, viewDir, vFragPos, shadow);
            }

            vec4 texColor = texture(uTexture, vUV);
            vec3 result = lighting * texColor.rgb * uObjectColor;

            float dist = length(vFragPos - uViewPos);
            float fogFactor = exp(-dist * uFogDensity);
            fogFactor = clamp(fogFactor, 0.0, 1.0);
            result = mix(uFogColor, result, fogFactor);

            // Без гаммы — bloom работает в линейном пространстве
            FragColor = vec4(result, texColor.a);
        }
    )";

    // ============================================================
    // DEPTH SHADERS
    // ============================================================

    static const char* s_DepthVertexSrc = R"(
        #version 330 core
        layout (location = 0) in vec3 aPos;
        uniform mat4 uModel;
        uniform mat4 uLightSpaceMatrix;
        void main() {
            gl_Position = uLightSpaceMatrix * uModel * vec4(aPos, 1.0);
        }
    )";

    static const char* s_DepthFragmentSrc = R"(
        #version 330 core
        void main() {}
    )";

    // ============================================================
    // WATER SHADERS
    // ============================================================

    static const char* s_WaterVertexSrc = R"(
        #version 330 core
        layout (location = 0) in vec3 aPos;
        layout (location = 1) in vec3 aNormal;
        layout (location = 2) in vec2 aUV;

        uniform mat4 uView;
        uniform mat4 uProjection;
        uniform float uTime;

        out vec3 vFragPos;
        out vec2 vUV;

        void main() {
            vec3 pos = aPos;

            pos.y += sin(pos.x * 0.5f + uTime * 1.5f) * 0.15f;
            pos.y += cos(pos.z * 0.7f + uTime * 1.2f) * 0.12f;
            pos.y += sin((pos.x + pos.z) * 0.3f + uTime * 0.8f) * 0.08f;

            vFragPos = pos;
            vUV = aUV;

            gl_Position = uProjection * uView * vec4(pos, 1.0);
        }
    )";

    static const char* s_WaterFragmentSrc = R"(
        #version 330 core
        in vec3 vFragPos;
        in vec2 vUV;

        out vec4 FragColor;

        uniform vec3 uViewPos;
        uniform vec3 uFogColor;
        uniform float uFogDensity;
        uniform vec3 uWaterColor;
        uniform float uTime;
        uniform float uWaterLevel;
        uniform vec3 uSkyColor;

        float TerrainHeight(float x, float z) {
            float h = 0.0;
            h += sin(x * 0.05) * 1.5;
            h += cos(z * 0.05) * 1.5;
            h += sin((x + z) * 0.08) * 0.8;
            h += 3.0;
            return h;
        }

        float hash(vec2 p) {
            return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }

        float noise(vec2 p) {
            vec2 i = floor(p);
            vec2 f = fract(p);
            float a = hash(i);
            float b = hash(i + vec2(1.0, 0.0));
            float c = hash(i + vec2(0.0, 1.0));
            float d = hash(i + vec2(1.0, 1.0));
            vec2 u = f * f * (3.0 - 2.0 * f);
            return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
        }

        void main() {
            vec2 refractedUV = vUV;
            refractedUV.x += sin(vFragPos.x * 0.8 + uTime * 1.5) * 0.08;
            refractedUV.y += cos(vFragPos.z * 0.8 + uTime * 1.2) * 0.08;

            float surfaceNoise = noise(refractedUV * 8.0 + uTime * 0.5);

            float wave1 = sin(vFragPos.x * 0.5 + uTime * 1.5);
            float wave2 = cos(vFragPos.z * 0.7 + uTime * 1.2);
            vec3 pseudoNormal = normalize(vec3(wave1 * 0.15, 1.0, wave2 * 0.15));

            vec3 viewDir = normalize(uViewPos - vFragPos);

            float fresnel = pow(1.0 - max(dot(pseudoNormal, viewDir), 0.0), 3.0);
            fresnel = clamp(fresnel, 0.0, 1.0);

            vec3 reflectionColor = mix(uWaterColor, uSkyColor, fresnel);

            vec3 refractedWaterColor = uWaterColor * (0.7 + surfaceNoise * 0.4);
            vec3 finalWaterColor = mix(refractedWaterColor, reflectionColor, 0.5);

            float landHeight = TerrainHeight(vFragPos.x, vFragPos.z);
            float waterDepth = uWaterLevel - landHeight;

            float foamEdge = 1.0 - smoothstep(0.0, 1.5, waterDepth);
            foamEdge = clamp(foamEdge, 0.0, 1.0);

            float foamWave = noise(vFragPos.xz * 3.0 + uTime * 0.6);
            float foamFine = noise(vFragPos.xz * 8.0 - uTime * 0.4);
            float foam = foamEdge * (foamWave * 0.7 + foamFine * 0.3) * 1.5;
            foam = clamp(foam, 0.0, 1.0);

            bool underwater = (uViewPos.y < uWaterLevel);

            vec3 finalColor;

            if (underwater) {
                float caustic = noise(refractedUV * 15.0 + uTime * 2.0);
                caustic = pow(caustic, 2.0);
                finalColor = uWaterColor * (0.4 + caustic * 0.6);
            } else {
                finalColor = finalWaterColor * 0.9;
                finalColor = mix(finalColor, vec3(1.0), foam * 0.8);
            }

            vec3 sunDir = normalize(vec3(0.3, 0.8, 0.5));
            vec3 halfDir = normalize(sunDir + viewDir);
            float spec = pow(max(dot(pseudoNormal, halfDir), 0.0), 128.0);
            finalColor += vec3(spec * 0.8);

            float dist = length(vFragPos - uViewPos);
            float fogFactor = exp(-dist * uFogDensity);
            fogFactor = clamp(fogFactor, 0.0, 1.0);
            finalColor = mix(uFogColor, finalColor, fogFactor);

            // Без гаммы — bloom работает в линейном пространстве
            float alpha = underwater ? 0.9 : 0.7;
            FragColor = vec4(finalColor, alpha);
        }
    )";

    // ============================================================
    // POST-PROCESSING SHADERS
    // ============================================================

    static const char* s_ScreenVertexSrc = R"(
        #version 330 core
        layout (location = 0) in vec2 aPos;
        layout (location = 1) in vec2 aUV;

        out vec2 vUV;

        void main() {
            vUV = aUV;
            gl_Position = vec4(aPos, 0.0, 1.0);
        }
    )";

    // Brightness pass — оставляем только яркое
    static const char* s_BrightnessFragmentSrc = R"(
        #version 330 core
        in vec2 vUV;
        out vec4 FragColor;

        uniform sampler2D uSceneTexture;
        uniform float uThreshold;

        void main() {
            vec3 color = texture(uSceneTexture, vUV).rgb;

            // Яркость пикселя
            float brightness = dot(color, vec3(0.2126, 0.7152, 0.0722));

            if (brightness > uThreshold) {
                FragColor = vec4(color, 1.0);
            } else {
                FragColor = vec4(0.0, 0.0, 0.0, 1.0);
            }
        }
    )";

    // Blur pass — гауссово размытие (5x5)
    static const char* s_BlurFragmentSrc = R"(
        #version 330 core
        in vec2 vUV;
        out vec4 FragColor;

        uniform sampler2D uImage;
        uniform bool uHorizontal;

        void main() {
            float weight[5] = float[] (0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216);

            vec3 result = texture(uImage, vUV).rgb * weight[0];

            if (uHorizontal) {
                vec2 texOffset = vec2(1.0 / textureSize(uImage, 0).x, 0.0);
                for (int i = 1; i < 5; ++i) {
                    result += texture(uImage, vUV + texOffset * i).rgb * weight[i];
                    result += texture(uImage, vUV - texOffset * i).rgb * weight[i];
                }
            } else {
                vec2 texOffset = vec2(0.0, 1.0 / textureSize(uImage, 0).y);
                for (int i = 1; i < 5; ++i) {
                    result += texture(uImage, vUV + texOffset * i).rgb * weight[i];
                    result += texture(uImage, vUV - texOffset * i).rgb * weight[i];
                }
            }

            FragColor = vec4(result, 1.0);
        }
    )";

    // Final composite — сцена + bloom + гамма
    static const char* s_ScreenFragmentSrc = R"(
        #version 330 core
        in vec2 vUV;
        out vec4 FragColor;

        uniform sampler2D uSceneTexture;
        uniform sampler2D uBloomTexture;
        uniform float uBloomIntensity;

        void main() {
            vec3 scene = texture(uSceneTexture, vUV).rgb;
            vec3 bloom = texture(uBloomTexture, vUV).rgb;

            // Сцена + bloom
            vec3 result = scene + bloom * uBloomIntensity;

            // Гамма-коррекция (в конце)
            result = pow(result, vec3(1.0 / 2.2));

            FragColor = vec4(result, 1.0);
        }
    )";

    // ============================================================
    // Helpers
    // ============================================================

    static unsigned int CompileShader(unsigned int type, const char* src) {
        unsigned int id = glCreateShader(type);
        glShaderSource(id, 1, &src, nullptr);
        glCompileShader(id);

        int result;
        glGetShaderiv(id, GL_COMPILE_STATUS, &result);
        if (!result) {
            int length;
            glGetShaderiv(id, GL_INFO_LOG_LENGTH, &length);
            char* message = new char[length];
            glGetShaderInfoLog(id, length, &length, message);
            Log::Error(std::string("Shader compilation failed: ") + message);
            delete[] message;
            glDeleteShader(id);
            return 0;
        }
        return id;
    }

    static unsigned int CreateShaderProgram(const char* vs, const char* fs) {
        unsigned int vsId = CompileShader(GL_VERTEX_SHADER, vs);
        unsigned int fsId = CompileShader(GL_FRAGMENT_SHADER, fs);
        if (!vsId || !fsId) return 0;

        unsigned int program = glCreateProgram();
        glAttachShader(program, vsId);
        glAttachShader(program, fsId);
        glLinkProgram(program);

        int result;
        glGetProgramiv(program, GL_LINK_STATUS, &result);
        if (!result) {
            int length;
            glGetProgramiv(program, GL_INFO_LOG_LENGTH, &length);
            char* message = new char[length];
            glGetProgramInfoLog(program, length, &length, message);
            Log::Error(std::string("Program link failed: ") + message);
            delete[] message;
            return 0;
        }

        glDeleteShader(vsId);
        glDeleteShader(fsId);
        return program;
    }

    unsigned int Renderer::LoadTexture(const char* path) {
        unsigned int texID;
        glGenTextures(1, &texID);
        glBindTexture(GL_TEXTURE_2D, texID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        int width, height, channels;
        stbi_set_flip_vertically_on_load(true);
        unsigned char* data = stbi_load(path, &width, &height, &channels, 0);
        if (data) {
            GLenum format = (channels == 4) ? GL_RGBA : GL_RGB;
            GLenum internalFormat = (channels == 4) ? GL_SRGB8_ALPHA8 : GL_SRGB8;
            glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, width, height, 0, format, GL_UNSIGNED_BYTE, data);
            glGenerateMipmap(GL_TEXTURE_2D);
            Log::Info(std::string("Texture loaded (sRGB): ") + path);
        } else {
            Log::Error(std::string("Failed to load texture: ") + path);
        }
        stbi_image_free(data);

        return texID;
    }

    // ============================================================
    // Renderer
    // ============================================================

    Renderer::Renderer()  {}

    Renderer::~Renderer() {
        for (int i = 0; i < MAX_SHADOW_LIGHTS; ++i) {
            if (m_ShadowLights[i].depthMapFBO) glDeleteFramebuffers(1, &m_ShadowLights[i].depthMapFBO);
            if (m_ShadowLights[i].depthMapTex) glDeleteTextures(1, &m_ShadowLights[i].depthMapTex);
        }
        if (m_SceneFBO)      glDeleteFramebuffers(1, &m_SceneFBO);
        if (m_SceneColorTex) glDeleteTextures(1, &m_SceneColorTex);
        if (m_SceneDepthRBO) glDeleteRenderbuffers(1, &m_SceneDepthRBO);
        if (m_BrightFBO)     glDeleteFramebuffers(1, &m_BrightFBO);
        if (m_BrightTex)     glDeleteTextures(1, &m_BrightTex);
        for (int i = 0; i < 2; ++i) {
            if (m_BlurFBO[i]) glDeleteFramebuffers(1, &m_BlurFBO[i]);
            if (m_BlurTex[i]) glDeleteTextures(1, &m_BlurTex[i]);
        }
        if (m_QuadVAO) glDeleteVertexArrays(1, &m_QuadVAO);
        if (m_QuadVBO) glDeleteBuffers(1, &m_QuadVBO);
    }

    void Renderer::Init() {
        Log::Info("Renderer initializing...");

        m_ShaderProgram     = CreateShaderProgram(s_VertexShaderSrc, s_FragmentShaderSrc);
        m_DepthProgram      = CreateShaderProgram(s_DepthVertexSrc, s_DepthFragmentSrc);
        m_WaterProgram      = CreateShaderProgram(s_WaterVertexSrc, s_WaterFragmentSrc);
        m_ScreenProgram     = CreateShaderProgram(s_ScreenVertexSrc, s_ScreenFragmentSrc);
        m_BrightnessProgram = CreateShaderProgram(s_ScreenVertexSrc, s_BrightnessFragmentSrc);
        m_BlurProgram       = CreateShaderProgram(s_ScreenVertexSrc, s_BlurFragmentSrc);

        if (!m_ShaderProgram || !m_DepthProgram || !m_WaterProgram ||
            !m_ScreenProgram || !m_BrightnessProgram || !m_BlurProgram) {
            Log::Error("Renderer failed to create shaders");
            return;
        }

        m_ModelLoc = glGetUniformLocation(m_ShaderProgram, "uModel");
        m_ViewLoc  = glGetUniformLocation(m_ShaderProgram, "uView");
        m_ProjLoc  = glGetUniformLocation(m_ShaderProgram, "uProjection");

        m_DModelLoc      = glGetUniformLocation(m_DepthProgram, "uModel");
        m_DLightSpaceLoc = glGetUniformLocation(m_DepthProgram, "uLightSpaceMatrix");

        InitShadowMaps();

        // Fullscreen quad
        float quadVerts[] = {
            -1.0f, -1.0f,  0.0f, 0.0f,
             1.0f, -1.0f,  1.0f, 0.0f,
             1.0f,  1.0f,  1.0f, 1.0f,
            -1.0f, -1.0f,  0.0f, 0.0f,
             1.0f,  1.0f,  1.0f, 1.0f,
            -1.0f,  1.0f,  0.0f, 1.0f,
        };

        glGenVertexArrays(1, &m_QuadVAO);
        glBindVertexArray(m_QuadVAO);

        glGenBuffers(1, &m_QuadVBO);
        glBindBuffer(GL_ARRAY_BUFFER, m_QuadVBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(quadVerts), quadVerts, GL_STATIC_DRAW);

        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);

        InitFramebuffer();
        InitBloomFramebuffers();

        glEnable(GL_DEPTH_TEST);

        Log::Info("Renderer ready");
    }

    void Renderer::InitShadowMaps() {
        for (int i = 0; i < MAX_SHADOW_LIGHTS; ++i) {
            glGenFramebuffers(1, &m_ShadowLights[i].depthMapFBO);
            glGenTextures(1, &m_ShadowLights[i].depthMapTex);
            glBindTexture(GL_TEXTURE_2D, m_ShadowLights[i].depthMapTex);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT,
                         SHADOW_WIDTH, SHADOW_HEIGHT, 0,
                         GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
            float borderColor[] = { 1.0f, 1.0f, 1.0f, 1.0f };
            glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);
            glBindFramebuffer(GL_FRAMEBUFFER, m_ShadowLights[i].depthMapFBO);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                                   GL_TEXTURE_2D, m_ShadowLights[i].depthMapTex, 0);
            glDrawBuffer(GL_NONE);
            glReadBuffer(GL_NONE);
        }
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        Log::Info("Shadow maps initialized");
    }

    void Renderer::InitFramebuffer() {
        glGenFramebuffers(1, &m_SceneFBO);
        glBindFramebuffer(GL_FRAMEBUFFER, m_SceneFBO);

        glGenTextures(1, &m_SceneColorTex);
        glBindTexture(GL_TEXTURE_2D, m_SceneColorTex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, m_FBOWidth, m_FBOHeight, 0,
                     GL_RGB, GL_FLOAT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                               GL_TEXTURE_2D, m_SceneColorTex, 0);

        glGenRenderbuffers(1, &m_SceneDepthRBO);
        glBindRenderbuffer(GL_RENDERBUFFER, m_SceneDepthRBO);
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, m_FBOWidth, m_FBOHeight);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT,
                                  GL_RENDERBUFFER, m_SceneDepthRBO);

        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
            Log::Error("Scene framebuffer not complete!");
        } else {
            Log::Info("Scene framebuffer initialized (HDR: RGB16F)");
        }

        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glBindRenderbuffer(GL_RENDERBUFFER, 0);
    }

    void Renderer::InitBloomFramebuffers() {
        // Brightness FBO (half-res для скорости)
        int halfW = m_FBOWidth / 2;
        int halfH = m_FBOHeight / 2;

        glGenFramebuffers(1, &m_BrightFBO);
        glBindFramebuffer(GL_FRAMEBUFFER, m_BrightFBO);

        glGenTextures(1, &m_BrightTex);
        glBindTexture(GL_TEXTURE_2D, m_BrightTex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, halfW, halfH, 0,
                     GL_RGB, GL_FLOAT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                               GL_TEXTURE_2D, m_BrightTex, 0);

        // Blur FBO × 2
        for (int i = 0; i < 2; ++i) {
            glGenFramebuffers(1, &m_BlurFBO[i]);
            glBindFramebuffer(GL_FRAMEBUFFER, m_BlurFBO[i]);

            glGenTextures(1, &m_BlurTex[i]);
            glBindTexture(GL_TEXTURE_2D, m_BlurTex[i]);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, halfW, halfH, 0,
                         GL_RGB, GL_FLOAT, nullptr);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                                   GL_TEXTURE_2D, m_BlurTex[i], 0);
        }

        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        Log::Info("Bloom framebuffers initialized");
    }

    void Renderer::RenderFullscreenQuad() {
        glBindVertexArray(m_QuadVAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glBindVertexArray(0);
    }

    void Renderer::BrightnessPass() {
        glBindFramebuffer(GL_FRAMEBUFFER, m_BrightFBO);
        glViewport(0, 0, m_FBOWidth / 2, m_FBOHeight / 2);
        glClear(GL_COLOR_BUFFER_BIT);

        glDisable(GL_DEPTH_TEST);

        glUseProgram(m_BrightnessProgram);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, m_SceneColorTex);
        glUniform1i(glGetUniformLocation(m_BrightnessProgram, "uSceneTexture"), 0);
        glUniform1f(glGetUniformLocation(m_BrightnessProgram, "uThreshold"), 1.0f);

        RenderFullscreenQuad();
    }

    void Renderer::BlurPass() {
        glDisable(GL_DEPTH_TEST);

        bool horizontal = true;
        const int iterations = 5;

        glUseProgram(m_BlurProgram);

        unsigned int sourceTex = m_BrightTex;

        for (int i = 0; i < iterations * 2; ++i) {
            glBindFramebuffer(GL_FRAMEBUFFER, m_BlurFBO[horizontal ? 0 : 1]);
            glViewport(0, 0, m_FBOWidth / 2, m_FBOHeight / 2);
            glClear(GL_COLOR_BUFFER_BIT);

            glUniform1i(glGetUniformLocation(m_BlurProgram, "uHorizontal"), horizontal ? 1 : 0);

            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, sourceTex);
            glUniform1i(glGetUniformLocation(m_BlurProgram, "uImage"), 0);

            RenderFullscreenQuad();

            sourceTex = m_BlurTex[horizontal ? 0 : 1];
            horizontal = !horizontal;
        }
    }

    void Renderer::CompositeToScreen() {
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glViewport(0, 0, m_FBOWidth, m_FBOHeight);
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        glDisable(GL_DEPTH_TEST);

        glUseProgram(m_ScreenProgram);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, m_SceneColorTex);
        glUniform1i(glGetUniformLocation(m_ScreenProgram, "uSceneTexture"), 0);

        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, m_BlurTex[0]);
        glUniform1i(glGetUniformLocation(m_ScreenProgram, "uBloomTexture"), 1);

        glUniform1f(glGetUniformLocation(m_ScreenProgram, "uBloomIntensity"), 0.8f);

        RenderFullscreenQuad();

        glEnable(GL_DEPTH_TEST);
    }

    void Renderer::BindFramebuffer() {
        glBindFramebuffer(GL_FRAMEBUFFER, m_SceneFBO);
        glViewport(0, 0, m_FBOWidth, m_FBOHeight);
    }

    void Renderer::UnbindFramebuffer() {
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
    }

    void Renderer::CollectShadowLights(const Scene& scene) {
        for (int i = 0; i < MAX_SHADOW_LIGHTS; ++i) m_ShadowLights[i].valid = false;
        int idx = 0;
        for (const auto& light : scene.GetLights()) {
            if (idx >= MAX_SHADOW_LIGHTS) break;
            LightType type = light.GetType();
            if (type != LightType::Directional && type != LightType::Spot) continue;
            ShadowLight& sl = m_ShadowLights[idx];
            sl.type      = (type == LightType::Directional) ? 1 : 2;
            sl.position  = light.GetPosition();
            sl.direction = light.GetDirection();
            sl.range     = light.GetRange();
            sl.cosInner  = light.GetCosInner();
            sl.cosOuter  = light.GetCosOuter();

            if (type == LightType::Directional) {
                glm::vec3 lightDir = glm::normalize(light.GetDirection());
                glm::vec3 lightPos = -lightDir * 30.0f;
                float size = 20.0f;
                glm::mat4 proj = glm::ortho(-size, size, -size, size, 0.1f, 100.0f);
                glm::mat4 view = glm::lookAt(lightPos, glm::vec3(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
                sl.lightSpaceMatrix = proj * view;
            } else {
                float fov = glm::radians(light.GetOuterAngle() * 2.0f + 10.0f);
                glm::mat4 proj = glm::perspective(fov, 1.0f, 0.1f, 100.0f);
                glm::vec3 target = sl.position + glm::normalize(sl.direction);
                glm::mat4 view = glm::lookAt(sl.position, target, glm::vec3(0.0f, 1.0f, 0.0f));
                sl.lightSpaceMatrix = proj * view;
            }
            sl.valid = true;
            idx++;
        }
    }

    void Renderer::RenderDepthMaps(const Scene& scene) {
        CollectShadowLights(scene);
        glViewport(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
        glDisable(GL_CULL_FACE);
        glUseProgram(m_DepthProgram);

        for (int i = 0; i < MAX_SHADOW_LIGHTS; ++i) {
            if (!m_ShadowLights[i].valid) continue;
            glBindFramebuffer(GL_FRAMEBUFFER, m_ShadowLights[i].depthMapFBO);
            glClear(GL_DEPTH_BUFFER_BIT);
            glUniformMatrix4fv(m_DLightSpaceLoc, 1, GL_FALSE,
                               glm::value_ptr(m_ShadowLights[i].lightSpaceMatrix));
            for (const auto& obj : scene.GetObjects()) {
                if (!obj.GetMesh()) continue;
                glm::mat4 model = obj.GetModelMatrix();
                glUniformMatrix4fv(m_DModelLoc, 1, GL_FALSE, glm::value_ptr(model));
                obj.GetMesh()->Draw();
            }
        }
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
    }

    void Renderer::BeginFrame() {}

    void Renderer::Draw(const glm::mat4& view,
                        const glm::mat4& projection,
                        const glm::vec3& cameraPos,
                        const Scene& scene,
                        float time)
    {
        RenderDepthMaps(scene);

        BindFramebuffer();

        glClearColor(0.01f, 0.01f, 0.02f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        if (m_Skybox) m_Skybox->Draw(view, projection);

        for (const auto& obj : scene.GetObjects()) {
            DrawObject(obj, view, projection, cameraPos, scene);
        }
    }

    void Renderer::DrawObject(const GameObject& obj,
                              const glm::mat4& view,
                              const glm::mat4& projection,
                              const glm::vec3& cameraPos,
                              const Scene& scene)
    {
        if (!obj.GetMesh()) return;

        glUseProgram(m_ShaderProgram);
        glm::mat4 model = obj.GetModelMatrix();

        glUniformMatrix4fv(m_ModelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(m_ViewLoc,  1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(m_ProjLoc,  1, GL_FALSE, glm::value_ptr(projection));

        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, m_ShadowLights[0].depthMapTex);
        glUniform1i(glGetUniformLocation(m_ShaderProgram, "uShadowMaps[0]"), 2);

        glActiveTexture(GL_TEXTURE3);
        glBindTexture(GL_TEXTURE_2D, m_ShadowLights[1].depthMapTex);
        glUniform1i(glGetUniformLocation(m_ShaderProgram, "uShadowMaps[1]"), 3);

        glUniformMatrix4fv(glGetUniformLocation(m_ShaderProgram, "uLightSpaceMatrices[0]"),
                           1, GL_FALSE, glm::value_ptr(m_ShadowLights[0].lightSpaceMatrix));
        glUniformMatrix4fv(glGetUniformLocation(m_ShaderProgram, "uLightSpaceMatrices[1]"),
                           1, GL_FALSE, glm::value_ptr(m_ShadowLights[1].lightSpaceMatrix));

        const auto& lights = scene.GetLights();
        int count = (int)lights.size();
        if (count > 8) count = 8;

        for (int i = 0; i < count; ++i) {
            const Light& l = lights[i];
            std::string base = "uLights[" + std::to_string(i) + "].";

            glUniform1i(glGetUniformLocation(m_ShaderProgram, (base + "type").c_str()), (int)l.GetType());
            glUniform3fv(glGetUniformLocation(m_ShaderProgram, (base + "position").c_str()), 1, glm::value_ptr(l.GetPosition()));
            glUniform3fv(glGetUniformLocation(m_ShaderProgram, (base + "direction").c_str()), 1, glm::value_ptr(l.GetDirection()));
            glUniform3fv(glGetUniformLocation(m_ShaderProgram, (base + "color").c_str()), 1, glm::value_ptr(l.GetColor()));
            glUniform1f(glGetUniformLocation(m_ShaderProgram, (base + "intensity").c_str()), l.GetIntensity());
            glUniform1f(glGetUniformLocation(m_ShaderProgram, (base + "range").c_str()), l.GetRange());
            glUniform1f(glGetUniformLocation(m_ShaderProgram, (base + "cosInner").c_str()), l.GetCosInner());
            glUniform1f(glGetUniformLocation(m_ShaderProgram, (base + "cosOuter").c_str()), l.GetCosOuter());

            int shadowIndex = -1;
            LightType lt = l.GetType();
            if (lt == LightType::Directional || lt == LightType::Spot) {
                int counter = 0;
                for (int j = 0; j < i; ++j) {
                    if (lights[j].GetType() == LightType::Directional ||
                        lights[j].GetType() == LightType::Spot) counter++;
                }
                if (counter < MAX_SHADOW_LIGHTS && m_ShadowLights[counter].valid) {
                    shadowIndex = counter;
                }
            }
            glUniform1i(glGetUniformLocation(m_ShaderProgram, (base + "shadowIndex").c_str()), shadowIndex);
        }

        glUniform1i(glGetUniformLocation(m_ShaderProgram, "uLightCount"), count);
        glUniform3fv(glGetUniformLocation(m_ShaderProgram, "uViewPos"), 1, glm::value_ptr(cameraPos));

        glm::vec3 fogColorSRGB(0.65f, 0.75f, 0.85f);
        glm::vec3 fogColor = glm::pow(fogColorSRGB, glm::vec3(2.2f));
        glUniform3fv(glGetUniformLocation(m_ShaderProgram, "uFogColor"),   1, glm::value_ptr(fogColor));
        glUniform1f (glGetUniformLocation(m_ShaderProgram, "uFogDensity"), 0.02f);

        glm::vec3 color = obj.GetColor();
        glUniform3fv(glGetUniformLocation(m_ShaderProgram, "uObjectColor"), 1, glm::value_ptr(color));

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, obj.GetTextureID());
        glUniform1i(glGetUniformLocation(m_ShaderProgram, "uTexture"), 0);

        obj.GetMesh()->Draw();
    }

    void Renderer::DrawWater(const Mesh& waterMesh,
                             const glm::mat4& view,
                             const glm::mat4& projection,
                             const glm::vec3& cameraPos,
                             float time)
    {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDepthMask(GL_FALSE);

        glUseProgram(m_WaterProgram);

        glUniformMatrix4fv(glGetUniformLocation(m_WaterProgram, "uView"),       1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(glGetUniformLocation(m_WaterProgram, "uProjection"), 1, GL_FALSE, glm::value_ptr(projection));
        glUniform3fv(glGetUniformLocation(m_WaterProgram, "uViewPos"),          1, glm::value_ptr(cameraPos));
        glUniform1f(glGetUniformLocation(m_WaterProgram, "uTime"), time);
        glUniform1f(glGetUniformLocation(m_WaterProgram, "uWaterLevel"), 4.0f);

        glm::vec3 skyColor(0.5f, 0.7f, 1.0f);
        glUniform3fv(glGetUniformLocation(m_WaterProgram, "uSkyColor"), 1, glm::value_ptr(skyColor));

        glm::vec3 fogColorSRGB(0.65f, 0.75f, 0.85f);
        glm::vec3 fogColor = glm::pow(fogColorSRGB, glm::vec3(2.2f));
        glUniform3fv(glGetUniformLocation(m_WaterProgram, "uFogColor"),   1, glm::value_ptr(fogColor));
        glUniform1f (glGetUniformLocation(m_WaterProgram, "uFogDensity"), 0.02f);

        glm::vec3 waterColor(0.1f, 0.3f, 0.5f);
        glUniform3fv(glGetUniformLocation(m_WaterProgram, "uWaterColor"), 1, glm::value_ptr(waterColor));

        waterMesh.Draw();

        glDepthMask(GL_TRUE);
        glDisable(GL_BLEND);

        // === BLOOM PIPELINE ===
        BrightnessPass();
        BlurPass();
        CompositeToScreen();
    }

}