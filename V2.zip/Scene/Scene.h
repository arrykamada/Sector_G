#pragma once
#include <vector>
#include <memory>
#include <utility>

#include "Scene/GameObject.h"
#include "Scene/Light.h"

namespace SectorG {

    class Scene {
    public:
        Scene() = default;

        // --- Objects ---
        void Add(const GameObject& obj) {
            m_Objects.push_back(obj);
        }

        const std::vector<GameObject>& GetObjects() const {
            return m_Objects;
        }

        // --- Lights ---
        void AddLight(const Light& light) {
            m_Lights.push_back(light);
        }

        const std::vector<Light>& GetLights() const {
            return m_Lights;
        }

        // Мутабельный доступ — для изменения света в реальном времени
        std::vector<Light>& GetLightsMutable() {
            return m_Lights;
        }

        // --- Коллайдеры ---
        void GetColliders(std::vector<std::pair<glm::vec3, glm::vec3>>& out) const {
            out.clear();
            for (const auto& obj : m_Objects) {
                if (obj.GetMesh() && obj.GetPosition().y > 0.01f) {
                    glm::vec3 mn, mx;
                    obj.GetAABB(mn, mx);
                    out.push_back({mn, mx});
                }
            }
        }

        // --- Общее ---
        void Clear() {
            m_Objects.clear();
            m_Lights.clear();
        }

        size_t Size() const { return m_Objects.size(); }

    private:
        std::vector<GameObject> m_Objects;
        std::vector<Light>      m_Lights;
    };

}