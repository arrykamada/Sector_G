#include "Scene/GameObject.h"

#include <glm/gtc/matrix_transform.hpp>

namespace SectorG {

    glm::mat4 GameObject::GetModelMatrix() const {
        glm::mat4 model = glm::mat4(1.0f);

        model = glm::translate(model, m_Position);
        model = glm::rotate(model, glm::radians(m_Rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(m_Rotation.y), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, glm::radians(m_Rotation.z), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, m_Scale);

        return model;
    }

    void GameObject::GetAABB(glm::vec3& outMin, glm::vec3& outMax) const {
        // Базовый куб 1x1x1, центрирован в 0
        glm::vec3 halfSize = m_Scale * 0.5f;
        outMin = m_Position - halfSize;
        outMax = m_Position + halfSize;
    }

}