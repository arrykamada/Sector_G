#include "Scene/Player.h"
#include "Core/Input.h"

#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <cmath>
#include <vector>

namespace SectorG {

    static float TerrainHeight(float x, float z) {
        float h = 0.0f;
        h += std::sin(x * 0.05f) * 1.5f;
        h += std::cos(z * 0.05f) * 1.5f;
        h += std::sin((x + z) * 0.08f) * 0.8f;
        h += 3.0f;
        return h;
    }

    // Должен совпадать с Application.cpp
    static const float WATER_LEVEL = 4.0f;

    Player::Player() {
        UpdateCamera();
    }

    void Player::Update(float dt, const Scene& scene) {
        HandleNoclipToggle();
        HandleMouseLook();

        if (m_Noclip) {
            glm::vec3 dir(0.0f);
            if (Input::IsKeyPressed(GLFW_KEY_W))          dir += m_Camera.GetFront();
            if (Input::IsKeyPressed(GLFW_KEY_S))          dir -= m_Camera.GetFront();
            if (Input::IsKeyPressed(GLFW_KEY_A))          dir -= m_Camera.GetRight();
            if (Input::IsKeyPressed(GLFW_KEY_D))          dir += m_Camera.GetRight();
            if (Input::IsKeyPressed(GLFW_KEY_SPACE))      dir += m_Camera.GetUp();
            if (Input::IsKeyPressed(GLFW_KEY_LEFT_SHIFT)) dir -= m_Camera.GetUp();

            if (glm::length(dir) > 0.0f)
                dir = glm::normalize(dir);

            float speed = m_Settings.WalkSpeed * 3.0f;
            m_Position += dir * speed * dt;
            m_Velocity           = glm::vec3(0.0f);
            m_HorizontalVelocity = glm::vec3(0.0f);
            m_Grounded           = false;
        } else {
            HandleCrouch();
            HandleMovement(dt);
            HandleGravity(dt);
            HandleJump();
        }

        UpdateCamera();
    }

    void Player::HandleMouseLook() {
        float dx = Input::GetMouseDeltaX();
        float dy = Input::GetMouseDeltaY();

        float newYaw   = m_Camera.GetYaw()   + dx * m_Settings.MouseSens;
        float newPitch = m_Camera.GetPitch() - dy * m_Settings.MouseSens;

        m_Camera.SetRotation(newYaw, newPitch);
        Input::ResetMouseDelta();
    }

    void Player::HandleMovement(float dt) {
        glm::vec3 front = m_Camera.GetFront();
        front.y = 0.0f;
        if (glm::length(front) > 0.0f) front = glm::normalize(front);

        glm::vec3 right = m_Camera.GetRight();
        right.y = 0.0f;
        if (glm::length(right) > 0.0f) right = glm::normalize(right);

        glm::vec3 wishDir(0.0f);
        if (Input::IsKeyPressed(GLFW_KEY_W)) wishDir += front;
        if (Input::IsKeyPressed(GLFW_KEY_S)) wishDir -= front;
        if (Input::IsKeyPressed(GLFW_KEY_A)) wishDir -= right;
        if (Input::IsKeyPressed(GLFW_KEY_D)) wishDir += right;

        if (glm::length(wishDir) > 0.0f)
            wishDir = glm::normalize(wishDir);

        float speed = m_Settings.WalkSpeed;
        if (m_Crouching)
            speed = m_Settings.CrouchSpeed;
        else if (Input::IsKeyPressed(GLFW_KEY_LEFT_SHIFT))
            speed = m_Settings.RunSpeed;

        glm::vec3 targetVel = wishDir * speed;

        float accel = 20.0f;
        float t = accel * dt;
        if (t > 1.0f) t = 1.0f;

        m_HorizontalVelocity.x += (targetVel.x - m_HorizontalVelocity.x) * t;
        m_HorizontalVelocity.z += (targetVel.z - m_HorizontalVelocity.z) * t;

        m_Position.x += m_HorizontalVelocity.x * dt;
        m_Position.z += m_HorizontalVelocity.z * dt;
    }

    void Player::HandleGravity(float dt) {
        m_Velocity.y -= m_Settings.Gravity * dt;
        m_Position.y += m_Velocity.y * dt;

        m_Grounded = false;

        float terrainY = TerrainHeight(m_Position.x, m_Position.z);

        // Коллизия: стоим на самой высокой из — земля или вода
        float groundY = terrainY;
        if (WATER_LEVEL > terrainY) {
            groundY = WATER_LEVEL;
        }

        if (m_Position.y <= groundY) {
            m_Position.y = groundY;
            m_Velocity.y = 0.0f;
            m_Grounded = true;
        }
    }

    void Player::HandleJump() {
        if (m_Grounded && Input::IsKeyPressed(GLFW_KEY_SPACE)) {
            m_Velocity.y = m_Settings.JumpForce;
            m_Grounded = false;
        }
    }

    void Player::HandleCrouch() {
        bool wantCrouch = Input::IsKeyPressed(GLFW_KEY_LEFT_CONTROL);
        m_Crouching = wantCrouch;

        float targetHeight = m_Crouching ? m_Settings.CrouchHeight
                                          : m_Settings.EyeHeight;

        m_CurrentEyeHeight += (targetHeight - m_CurrentEyeHeight) * 0.2f;
    }

    void Player::HandleNoclipToggle() {
        static bool prevV = false;
        bool currV = Input::IsKeyPressed(GLFW_KEY_V);

        if (currV && !prevV) {
            m_Noclip = !m_Noclip;
        }
        prevV = currV;
    }

    void Player::UpdateCamera() {
        m_Camera.SetPosition(m_Position + glm::vec3(0.0f, m_CurrentEyeHeight, 0.0f));
    }

}