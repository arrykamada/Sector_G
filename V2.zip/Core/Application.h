#pragma once
#include <memory>
#include <vector>

#include "Core/Window.h"
#include "Render/Renderer.h"
#include "Scene/Player.h"
#include "Scene/Scene.h"

namespace SectorG {

    class Application {
    public:
        Application();
        ~Application();

        Application(const Application&)            = delete;
        Application& operator=(const Application&) = delete;

        void Run();

    private:
        void SetupScene();

        std::unique_ptr<Window>   m_Window;
        std::unique_ptr<Renderer> m_Renderer;
        std::unique_ptr<Player>   m_Player;
        std::shared_ptr<Mesh>     m_TerrainMesh;
        std::shared_ptr<Mesh>     m_WaterMesh;
        Scene                     m_Scene;
        bool m_Running = true;
    };

}