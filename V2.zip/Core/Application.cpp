#include "Core/Application.h"
#include "Core/Input.h"
#include "Utils/Log.h"

#include <cmath>

namespace SectorG {

    // Должна СОВПАДАТЬ с Mesh::TerrainHeightFunc и Player.cpp
    static float TerrainHeight(float x, float z) {
        float h = 0.0f;
        h += std::sin(x * 0.05f) * 1.5f;
        h += std::cos(z * 0.05f) * 1.5f;
        h += std::sin((x + z) * 0.08f) * 0.8f;
        h += 3.0f;
        return h;
    }

    // Уровень воды (должен совпадать с Player.cpp)
    static const float WATER_LEVEL = 4.0f;

    Application::Application() {
        Log::Info("Application created");

        m_Window = std::make_unique<Window>(WindowProps{
            "Sector_G", 1280, 720
        });

        m_Renderer = std::make_unique<Renderer>();
        m_Renderer->Init();

        m_Renderer->m_Skybox = std::make_unique<Skybox>();
        m_Renderer->m_Skybox->Load("assets/s.png");

        m_Player = std::make_unique<Player>();
        m_Player->Settings().WalkSpeed = 8.0f;
        m_Player->Settings().RunSpeed  = 14.0f;
        m_Player->Settings().JumpForce = 10.0f;
        m_Player->Settings().Gravity   = 22.0f;

        SetupScene();
    }

    Application::~Application() {
        Log::Info("Application destroyed");
    }

    void Application::SetupScene() {
        Log::Info("Setting up scene...");

        m_TerrainMesh = std::make_shared<Mesh>(Mesh::CreateTerrain(60.0f, 128));
        m_WaterMesh   = std::make_shared<Mesh>(Mesh::CreateWaterPlane(60.0f, 64, WATER_LEVEL));

        unsigned int grassTex = Renderer::LoadTexture("assets/test.jpg");

        // Ландшафт
        m_Scene.Add(GameObject(
            m_TerrainMesh,
            grassTex,
            glm::vec3(0.0f, 0.0f, 0.0f),
            glm::vec3(0.0f),
            glm::vec3(1.0f),
            glm::vec3(1.0f)
        ));

        // --- Свет ---

        m_Scene.AddLight(Light::CreatePoint(
            glm::vec3(3.0f, 12.0f, 3.0f),
            glm::vec3(1.0f, 0.95f, 0.85f),
            1.0f,
            40.0f
        ));

        m_Scene.AddLight(Light::CreatePoint(
            glm::vec3(-10.0f, 6.0f, -10.0f),
            glm::vec3(0.25f, 0.35f, 0.6f),
            0.6f,
            35.0f
        ));

        m_Scene.AddLight(Light::CreateDirectional(
            glm::vec3(0.3f, -0.8f, -0.5f),
            glm::vec3(0.7f, 0.7f, 0.75f),
            1.3f
        ));

        m_Scene.AddLight(Light::CreateSpot(
            glm::vec3(0.0f, 20.0f, 0.0f),
            glm::vec3(0.0f, -1.0f, 0.0f),
            glm::vec3(1.0f, 0.5f, 0.3f),
            1.5f, 40.0f, 25.0f, 35.0f
        ));

        Log::Info("Scene has " + std::to_string(m_Scene.Size()) + " objects and " +
                  std::to_string(m_Scene.GetLights().size()) + " lights");
    }

    void Application::Run() {
        Log::Info("Main loop started");

        float time = 0.0f;
        float dt   = 0.016f;

        while (m_Running && !m_Window->ShouldClose()) {
            time += dt;

            auto& lights = m_Scene.GetLightsMutable();
            if (!lights.empty()) {
                float radius = 10.0f;
                float speed  = 0.6f;
                float height = 10.0f + std::sin(time * 0.5f) * 2.0f;

                float angle = time * speed;
                lights[0].SetPosition(glm::vec3(
                    std::cos(angle) * radius,
                    height,
                    std::sin(angle) * radius
                ));
            }

            m_Player->Update(dt, m_Scene);

            const Camera& cam = m_Player->GetCamera();

            float aspect = (float)m_Window->GetWidth() / (float)m_Window->GetHeight();
            glm::mat4 view       = cam.GetViewMatrix();
            glm::mat4 projection = cam.GetProjectionMatrix(aspect);

            m_Renderer->BeginFrame();

            // Скайбокс
            if (m_Renderer->m_Skybox) {
                m_Renderer->m_Skybox->Draw(view, projection);
            }

            // Основные объекты (ландшафт)
            m_Renderer->Draw(view, projection, cam.GetPosition(), m_Scene, time);

            // Вода (отдельный проход с прозрачностью)
            m_Renderer->DrawWater(*m_WaterMesh, view, projection, cam.GetPosition(), time);

            m_Window->OnUpdate();
        }

        Log::Info("Main loop stopped");
    }

}