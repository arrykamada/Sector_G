#include "Scene/Player.h"
#include "Scene/Terrain.h"
#include "Core/Input.h"

#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <algorithm>
#include <cmath>
#include <vector>

namespace SectorG {

    Player::Player() {
        UpdateCamera();
    }

    // ============================================================
    //  Update
    // ============================================================
    void Player::Update(float dt, const Scene& scene) {
        HandleNoclipToggle();
        HandleMouseLook();

        if (m_Noclip) {
            glm::vec3 dir(0.0f);
            if (Input::IsKeyPressed(GLFW_KEY_W))          dir += m_Camera.GetFront();
            if (Input::IsKeyPressed(GLFW_KEY_S))          dir -= m_Camera.GetFront();
            if (Input::IsKeyPressed(GLFW_KEY_A))          dir -= m_Camera.GetRight();
            if (Input::IsKeyPressed(GLFW_KEY_D))          dir += m_Camera.GetRight();
            if (Input::IsKeyPressed(GLFW_KEY_SPACE))      dir += m_Camera.GetUp();
            if (Input::IsKeyPressed(GLFW_KEY_LEFT_SHIFT)) dir -= m_Camera.GetUp();

            if (glm::length(dir) > 0.0f)
                dir = glm::normalize(dir);

            float speed = m_Settings.WalkSpeed * 3.0f;
            m_Position += dir * speed * dt;
            m_Velocity           = glm::vec3(0.0f);
            m_HorizontalVelocity = glm::vec3(0.0f);
            m_Grounded           = false;
        } else {
            HandleCrouch();
            HandleMovement(dt);
            HandleJump();
            HandleGravity(dt);

            ResolveCollisions(scene);
        }

        UpdateCamera();
    }

    // ============================================================
    //  Mouse look
    // ============================================================
    void Player::HandleMouseLook() {
        float dx = Input::GetMouseDeltaX();
        float dy = Input::GetMouseDeltaY();

        float newYaw   = m_Camera.GetYaw()   + dx * m_Settings.MouseSens;
        float newPitch = m_Camera.GetPitch() - dy * m_Settings.MouseSens;

        m_Camera.SetRotation(newYaw, newPitch);
        Input::ResetMouseDelta();
    }

    // ============================================================
    //  HandleMovement — только считаем горизонтальную скорость
    //  и добавляем к позиции. Разрешение — в ResolveCollisions.
    // ============================================================
    void Player::HandleMovement(float dt) {
        glm::vec3 front = m_Camera.GetFront();
        front.y = 0.0f;
        if (glm::length(front) > 0.0f) front = glm::normalize(front);

        glm::vec3 right = m_Camera.GetRight();
        right.y = 0.0f;
        if (glm::length(right) > 0.0f) right = glm::normalize(right);

        glm::vec3 wishDir(0.0f);
        if (Input::IsKeyPressed(GLFW_KEY_W)) wishDir += front;
        if (Input::IsKeyPressed(GLFW_KEY_S)) wishDir -= front;
        if (Input::IsKeyPressed(GLFW_KEY_A)) wishDir -= right;
        if (Input::IsKeyPressed(GLFW_KEY_D)) wishDir += right;

        if (glm::length(wishDir) > 0.0f)
            wishDir = glm::normalize(wishDir);

        float speed = m_Settings.WalkSpeed;
        if (m_Crouching)
            speed = m_Settings.CrouchSpeed;
        else if (Input::IsKeyPressed(GLFW_KEY_LEFT_SHIFT))
            speed = m_Settings.RunSpeed;

        glm::vec3 targetVel = wishDir * speed;

        float accel = 20.0f;
        float t = accel * dt;
        if (t > 1.0f) t = 1.0f;

        m_HorizontalVelocity.x += (targetVel.x - m_HorizontalVelocity.x) * t;
        m_HorizontalVelocity.z += (targetVel.z - m_HorizontalVelocity.z) * t;

        // Двигаем напрямую — ResolveCollisions потом откатит, если что
        m_Position.x += m_HorizontalVelocity.x * dt;
        m_Position.z += m_HorizontalVelocity.z * dt;
    }

    // ============================================================
    //  HandleGravity — вертикальная скорость
    // ============================================================
    void Player::HandleGravity(float dt) {
        m_Velocity.y -= m_Settings.Gravity * dt;
        m_Position.y += m_Velocity.y * dt;

        m_Grounded = false;

        // Земля (террейн + вода)
        float terrainY = TerrainHeight(m_Position.x, m_Position.z);
        float groundY  = std::max(terrainY, WATER_LEVEL);

        if (m_Position.y <= groundY) {
            m_Position.y = groundY;
            m_Velocity.y = 0.0f;
            m_Grounded   = true;
        }
    }

    // ============================================================
    //  Jump
    // ============================================================
    void Player::HandleJump() {
        if (m_Grounded && Input::IsKeyPressed(GLFW_KEY_SPACE)) {
            m_Velocity.y = m_Settings.JumpForce;
            m_Grounded   = false;
        }
    }

    // ============================================================
    //  Crouch
    // ============================================================
    void Player::HandleCrouch() {
        bool wantCrouch = Input::IsKeyPressed(GLFW_KEY_LEFT_CONTROL);
        m_Crouching = wantCrouch;

        float targetHeight = m_Crouching ? m_Settings.CrouchHeight
                                          : m_Settings.EyeHeight;

        m_CurrentEyeHeight += (targetHeight - m_CurrentEyeHeight) * 0.2f;
    }

    // ============================================================
    //  Noclip toggle
    // ============================================================
    void Player::HandleNoclipToggle() {
        static bool prevV = false;
        bool currV = Input::IsKeyPressed(GLFW_KEY_V);

        if (currV && !prevV) {
            m_Noclip = !m_Noclip;
        }
        prevV = currV;
    }

    // ============================================================
    //  Camera follows player
    // ============================================================
    void Player::UpdateCamera() {
        m_Camera.SetPosition(m_Position + glm::vec3(0.0f, m_CurrentEyeHeight, 0.0f));
    }

    // ============================================================
    //  CheckAABBCollision — оставлен для совместимости,
    //  но НЕ используется в ResolveCollisions.
    //  Возвращает true, если AABB игрока пересекается с obj AABB.
    // ============================================================
    bool Player::CheckAABBCollision(const glm::vec3& objMin,
                                    const glm::vec3& objMax,
                                    glm::vec3& outPushDir,
                                    float& outPushDist) const
    {
        const float r = m_Settings.PlayerRadius;
        const float h = m_Crouching ? m_Settings.CrouchHeight
                                    : m_Settings.PlayerHeight;

        glm::vec3 pMin(m_Position.x - r, m_Position.y,     m_Position.z - r);
        glm::vec3 pMax(m_Position.x + r, m_Position.y + h, m_Position.z + r);

        bool overlap = (pMin.x < objMax.x && pMax.x > objMin.x) &&
                       (pMin.y < objMax.y && pMax.y > objMin.y) &&
                       (pMin.z < objMax.z && pMax.z > objMin.z);
        if (!overlap) return false;

        // минимальное выталкивание
        float px = std::min(objMax.x - pMin.x, pMax.x - objMin.x);
        float py = std::min(objMax.y - pMin.y, pMax.y - objMin.y);
        float pz = std::min(objMax.z - pMin.z, pMax.z - objMin.z);

        outPushDir = glm::vec3(0.0f);
        outPushDist = px;
        int axis = 0;
        if (py < outPushDist) { outPushDist = py; axis = 1; }
        if (pz < outPushDist) { outPushDist = pz; axis = 2; }

        outPushDir[axis] = 1.0f;
        return true;
    }

    // ============================================================
    //  Хелпер: пересекается ли AABB игрока с AABB объекта
    //  В КОНКРЕТНОЙ позиции (pos передаётся, чтобы можно было
    //  проверять "а что если я сдвинусь сюда").
    // ============================================================
    static bool OverlapsAt(const glm::vec3& pos,
                           float radius, float height,
                           const glm::vec3& objMin,
                           const glm::vec3& objMax)
    {
        glm::vec3 pMin(pos.x - radius, pos.y,          pos.z - radius);
        glm::vec3 pMax(pos.x + radius, pos.y + height, pos.z + radius);

        return (pMin.x < objMax.x && pMax.x > objMin.x) &&
               (pMin.y < objMax.y && pMax.y > objMin.y) &&
               (pMin.z < objMax.z && pMax.z > objMin.z);
    }

    // ============================================================
    //  ResolveCollisions — движение по одной оси с откатом.
    //
    //  Идея: HandleMovement уже сдвинул m_Position по X и Z.
    //  Здесь мы проверяем, не влезли ли мы в чужой AABB.
    //  Если влезли — откатываем ИМЕННО ту ось, по которой только что
    //  двигались. Так игрок не «выкидывает в бок».
    // ============================================================
    void Player::ResolveCollisions(const Scene& scene) {
        std::vector<std::pair<glm::vec3, glm::vec3>> colliders;
        scene.GetColliders(colliders);

        const float r = m_Settings.PlayerRadius;
        const float h = m_Crouching ? m_Settings.CrouchHeight
                                    : m_Settings.PlayerHeight;

        // ============================================================
        //  1) Разрешение по X
        //     HandleMovement уже сдвинул позицию. Проверяем — если
        //     сейчас пересекаемся с чем-то, откатываем X.
        //     Но чтобы «откатить X», надо знать, на сколько мы сдвинулись.
        //     Проще: пробуем сдвинуть X-позицию в сторону от объекта,
        //     пока не выйдем из пересечения.
        // ============================================================
        for (int iter = 0; iter < 4; ++iter) {   // несколько итераций для устойчивости
            bool corrected = false;

            for (const auto& c : colliders) {
                if (!OverlapsAt(m_Position, r, h, c.first, c.second))
                    continue;

                // Мы внутри — выталкиваем по НАИМЕНЬШЕЙ оси,
                // но с учётом того, куда игрок ХОТЕЛ двигаться.
                // Если горизонтальная скорость по X доминирует —
                // выталкиваем по X.
                // Если по Z — по Z.
                // Иначе — по Y (стоим на объекте / упираемся головой).

                glm::vec3 pMin(m_Position.x - r, m_Position.y,     m_Position.z - r);
                glm::vec3 pMax(m_Position.x + r, m_Position.y + h, m_Position.z + r);

                float pushPosX = c.second.x - pMin.x;
                float pushNegX = pMax.x - c.first.x;
                float pushPosY = c.second.y - pMin.y;
                float pushNegY = pMax.y - c.first.y;
                float pushPosZ = c.second.z - pMin.z;
                float pushNegZ = pMax.z - c.first.z;

                // Кандидаты: (ось, направление, величина)
                float bestDist = pushPosX;
                int   bestAxis = 0;
                float bestSign = +1.0f;

                auto consider = [&](int axis, float sign, float dist) {
                    if (dist < bestDist) {
                        bestDist = dist;
                        bestAxis = axis;
                        bestSign = sign;
                    }
                };

                consider(0, -1.0f, pushNegX);
                consider(1, +1.0f, pushPosY);
                consider(1, -1.0f, pushNegY);
                consider(2, +1.0f, pushPosZ);
                consider(2, -1.0f, pushNegZ);

                // Применяем выталкивание
                m_Position[bestAxis] += bestSign * bestDist;

                // Гасим скорость по этой оси
                if (bestAxis == 0) m_HorizontalVelocity.x = 0.0f;
                if (bestAxis == 2) m_HorizontalVelocity.z = 0.0f;
                if (bestAxis == 1) {
                    if (bestSign > 0.0f && m_Velocity.y < 0.0f) {
                        m_Velocity.y = 0.0f;
                        m_Grounded   = true;
                    } else if (bestSign < 0.0f && m_Velocity.y > 0.0f) {
                        m_Velocity.y = 0.0f;
                    }
                }

                corrected = true;
                break;   // перезапустить проход с новой позицией
            }

            if (!corrected) break;
        }
    }

}