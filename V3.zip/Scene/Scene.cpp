#include "Scene/Scene.h"

// Пока всё в заголовке (inline методы).
// Файл нужен, чтобы CMake собирал Scene и не ругался,
// если понадобится добавить что-то в .cpp позже.

namespace SectorG {
    // пусто — всё inline
}