#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/constants.hpp>
#include <cmath>

namespace SectorG {

    enum class LightType {
        Point,
        Directional,
        Spot
    };

    class Light {
    public:
        Light() = default;

        static Light CreatePoint(const glm::vec3& position,
                                 const glm::vec3& color,
                                 float intensity = 1.0f,
                                 float range = 20.0f)
        {
            Light l;
            l.m_Type      = LightType::Point;
            l.m_Position  = position;
            l.m_Color     = color;
            l.m_Intensity = intensity;
            l.m_Range     = range;
            return l;
        }

        static Light CreateDirectional(const glm::vec3& direction,
                                       const glm::vec3& color,
                                       float intensity = 1.0f)
        {
            Light l;
            l.m_Type      = LightType::Directional;
            l.m_Direction = glm::normalize(direction);
            l.m_Color     = color;
            l.m_Intensity = intensity;
            return l;
        }

        static Light CreateSpot(const glm::vec3& position,
                                const glm::vec3& direction,
                                const glm::vec3& color,
                                float intensity = 1.0f,
                                float range = 20.0f,
                                float innerAngle = 15.0f,
                                float outerAngle = 25.0f)
        {
            Light l;
            l.m_Type       = LightType::Spot;
            l.m_Position   = position;
            l.m_Direction  = glm::normalize(direction);
            l.m_Color      = color;
            l.m_Intensity  = intensity;
            l.m_Range      = range;
            l.m_InnerAngle = innerAngle;
            l.m_OuterAngle = outerAngle;
            return l;
        }

        LightType GetType() const { return m_Type; }

        const glm::vec3& GetPosition()  const { return m_Position; }
        const glm::vec3& GetDirection() const { return m_Direction; }
        const glm::vec3& GetColor()     const { return m_Color; }
        float GetIntensity() const { return m_Intensity; }
        float GetRange()     const { return m_Range; }
        float GetInnerAngle() const { return m_InnerAngle; }
        float GetOuterAngle() const { return m_OuterAngle; }

        glm::vec3 GetEffectiveColor() const {
            return m_Color * m_Intensity;
        }

        float GetCosInner() const { return std::cos(glm::radians(m_InnerAngle)); }
        float GetCosOuter() const { return std::cos(glm::radians(m_OuterAngle)); }

        void SetPosition(const glm::vec3& p)  { m_Position = p; }
        void SetDirection(const glm::vec3& d) { m_Direction = glm::normalize(d); }
        void SetColor(const glm::vec3& c)     { m_Color = c; }
        void SetIntensity(float i)            { m_Intensity = i; }
        void SetRange(float r)                { m_Range = r; }

    private:
        LightType m_Type = LightType::Point;

        glm::vec3 m_Position  = glm::vec3(0.0f);
        glm::vec3 m_Direction = glm::vec3(0.0f, -1.0f, 0.0f);
        glm::vec3 m_Color     = glm::vec3(1.0f);

        float m_Intensity  = 1.0f;
        float m_Range      = 20.0f;
        float m_InnerAngle = 15.0f;
        float m_OuterAngle = 25.0f;
    };

}