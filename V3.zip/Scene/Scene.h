#pragma once
#include <vector>
#include <memory>
#include <utility>

#include "Scene/GameObject.h"
#include "Scene/Light.h"
#include "Scene/Raycast.h"

namespace SectorG {

    class Scene {
    public:
        Scene() = default;

        // --- Objects ---
        void Add(const GameObject& obj) {
            m_Objects.push_back(obj);
        }

        const std::vector<GameObject>& GetObjects() const {
            return m_Objects;
        }

        // --- Lights ---
        void AddLight(const Light& light) {
            m_Lights.push_back(light);
        }

        const std::vector<Light>& GetLights() const {
            return m_Lights;
        }

        std::vector<Light>& GetLightsMutable() {
            return m_Lights;
        }

        // --- Коллайдеры ---
        void GetColliders(std::vector<std::pair<glm::vec3, glm::vec3>>& out) const {
            out.clear();
            for (const auto& obj : m_Objects) {
                if (obj.GetMesh() && obj.GetPosition().y > 0.01f) {
                    glm::vec3 mn, mx;
                    obj.GetAABB(mn, mx);
                    out.push_back({mn, mx});
                }
            }
        }

        // ============================================================
        // RAYCAST
        // ============================================================
        // Возвращает ближайшее попадание по всем объектам сцены.
        // Если ни во что не попал — result.hit == false.
        RayHit Raycast(const glm::vec3& origin,
                       const glm::vec3& dir,
                       float maxDistance = 1000.0f) const
        {
            RayHit best;
            best.hit = false;

            Ray ray;
            ray.origin = origin;
            ray.dir    = glm::normalize(dir);

            for (const auto& obj : m_Objects) {
                if (!obj.GetMesh()) continue;

                glm::vec3 mn, mx;
                obj.GetAABB(mn, mx);

                RayHit h = RayIntersectAABB(ray, mn, mx);
                if (!h.hit) continue;
                if (h.distance > maxDistance) continue;
                if (h.distance < best.distance) {
                    best = h;
                    best.hit = true;
                }
            }

            return best;
        }

        // Перегрузка — возвращает ещё и указатель на объект.
        // Внимание: указатель живёт, пока вектор m_Objects не перестроится
        // (не вызывай Add/Clear между получением и использованием).
        RayHit Raycast(const glm::vec3& origin,
                       const glm::vec3& dir,
                       float maxDistance,
                       const GameObject** outObject) const
        {
            RayHit best;
            best.hit = false;
            if (outObject) *outObject = nullptr;

            Ray ray;
            ray.origin = origin;
            ray.dir    = glm::normalize(dir);

            for (const auto& obj : m_Objects) {
                if (!obj.GetMesh()) continue;

                glm::vec3 mn, mx;
                obj.GetAABB(mn, mx);

                RayHit h = RayIntersectAABB(ray, mn, mx);
                if (!h.hit) continue;
                if (h.distance > maxDistance) continue;
                if (h.distance < best.distance) {
                    best = h;
                    best.hit = true;
                    if (outObject) *outObject = &obj;
                }
            }

            return best;
        }

        // --- Общее ---
        void Clear() {
            m_Objects.clear();
            m_Lights.clear();
        }

        size_t Size() const { return m_Objects.size(); }

    private:
        std::vector<GameObject> m_Objects;
        std::vector<Light>      m_Lights;
    };

}