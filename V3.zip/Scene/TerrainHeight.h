#pragma once
#include <cmath>

namespace SectorG {

    // Единая функция высоты ландшафта.
    // Используется в Mesh.cpp, Application.cpp, Player.cpp.
    inline float TerrainHeight(float x, float z) {
        float h = 0.0f;
        h += std::sin(x * 0.05f) * 1.5f;
        h += std::cos(z * 0.05f) * 1.5f;
        h += std::sin((x + z) * 0.08f) * 0.8f;
        h += 3.0f;
        return h;
    }

}