#pragma once
#include <glm/glm.hpp>
#include <cmath>
#include <algorithm>

namespace SectorG {

    // ============================================================
    //  ЕДИНЫЙ ИСТОЧНИК ПРАВДЫ О ЛАНДШАФТЕ
    //  Меняешь тут — меняется везде: меш, вода, игрок, шейдер.
    //  Формулу ОБЯЗАТЕЛЬНО дублировать в GLSL (см. комментарий снизу),
    //  либо прокидывать как uniform-массив.
    // ============================================================

    constexpr float WATER_LEVEL    = 2.0f;
    constexpr float ISLAND_RADIUS  = 90.0f;

    // --- Хэш и value-noise ---
    inline float Hash2(float x, float z) {
        float h = std::sin(x * 127.1f + z * 311.7f) * 43758.5453f;
        return h - std::floor(h);
    }

    inline float ValueNoise(float x, float z) {
        float xi = std::floor(x), zi = std::floor(z);
        float xf = x - xi,       zf = z - zi;
        float u = xf * xf * (3.0f - 2.0f * xf);
        float v = zf * zf * (3.0f - 2.0f * zf);

        float a = Hash2(xi,      zi);
        float b = Hash2(xi + 1,  zi);
        float c = Hash2(xi,      zi + 1);
        float d = Hash2(xi + 1,  zi + 1);

        float ab = a + (b - a) * u;
        float cd = c + (d - c) * u;
        return ab + (cd - ab) * v;
    }

    // FBM — 5 октав
    inline float FBM(float x, float z) {
        float v = 0.0f;
        float a = 0.5f;
        for (int i = 0; i < 5; ++i) {
            v += a * ValueNoise(x, z);
            x *= 2.03f;
            z *= 2.03f;
            a *= 0.5f;
        }
        return v;
    }

    inline float Smoothstep(float e0, float e1, float x) {
        float t = std::clamp((x - e0) / (e1 - e0), 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    }

    // ============================================================
    //  ФУНКЦИЯ ВЫСОТЫ ЛАНДШАФТА
    //  Возвращает высоту в мировых координатах.
    //  Вода стоит на WATER_LEVEL, всё что ниже — под водой.
    // ============================================================
    inline float TerrainHeight(float x, float z) {
        float dist = std::sqrt(x * x + z * z);

        // Плавная маска острова: 1 внутри, 0 снаружи радиуса
        float islandMask = 1.0f - Smoothstep(ISLAND_RADIUS * 0.55f,
                                             ISLAND_RADIUS, dist);

        // 1. Базовая форма — пологий купол
        float tDome = std::clamp(dist / ISLAND_RADIUS, 0.0f, 1.0f);
        float dome  = (1.0f - tDome * tDome) * 9.0f;

        // 2. Крупные горы/хребты через FBM
        float mountains = (FBM(x * 0.013f, z * 0.013f) - 0.5f) * 26.0f;

        // 3. Средняя детализация — холмы
        float hills = (FBM(x * 0.05f, z * 0.05f) - 0.5f) * 5.0f;

        // 4. Мелкая детализация — неровности почвы
        float detail = (FBM(x * 0.18f, z * 0.18f) - 0.5f) * 1.2f;

        // Смешиваем
        float h = dome + mountains + hills + detail;
        h *= islandMask;

        // Снаружи острова — плавно уходит под воду
        h -= (1.0f - islandMask) * 3.0f;

        // Не даём уйти слишком глубоко
        return std::max(h, -8.0f);
    }

}