#pragma once
#include <glm/glm.hpp>

namespace SectorG {

    class Camera {
    public:
        Camera();

        // --- Трансформ ---
        void SetPosition(const glm::vec3& pos) { m_Position = pos; }
        void SetYaw(float yaw);
        void SetPitch(float pitch);
        void SetRotation(float yaw, float pitch);

        const glm::vec3& GetPosition() const { return m_Position; }
        float GetYaw()   const { return m_Yaw; }
        float GetPitch() const { return m_Pitch; }

        // --- Векторы направления ---
        glm::vec3 GetFront() const { return m_Front; }
        glm::vec3 GetRight() const { return m_Right; }
        glm::vec3 GetUp()    const { return m_Up; }

        // --- Матрицы ---
        glm::mat4 GetViewMatrix() const;
        glm::mat4 GetProjectionMatrix(float aspect) const;

    private:
        void UpdateVectors();

        glm::vec3 m_Position;
        glm::vec3 m_Front;
        glm::vec3 m_Up;
        glm::vec3 m_Right;
        glm::vec3 m_WorldUp;

        float m_Yaw;
        float m_Pitch;
    };

}