#include "Scene/GameObject.h"

#include <glm/gtc/matrix_transform.hpp>
#include <algorithm>

namespace SectorG {

    glm::mat4 GameObject::GetModelMatrix() const {
        glm::mat4 model = glm::mat4(1.0f);

        model = glm::translate(model, m_Position);
        model = glm::rotate(model, glm::radians(m_Rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(m_Rotation.y), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, glm::radians(m_Rotation.z), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, m_Scale);

        return model;
    }

    void GameObject::GetAABB(glm::vec3& outMin, glm::vec3& outMax) const {
        // Если меша нет — считаем объект кубом 1×1×1 (как раньше)
        if (!m_Mesh) {
            glm::vec3 halfSize = m_Scale * 0.5f;
            outMin = m_Position - halfSize;
            outMax = m_Position + halfSize;
            return;
        }

        // Локальный AABB меша (например, дом: -5..5 по X/Z, 0..10 по Y)
        glm::vec3 localMin = m_Mesh->GetLocalMin();
        glm::vec3 localMax = m_Mesh->GetLocalMax();

        // Масштаб — покомпонентно, позиция — сдвиг
        glm::vec3 wMin = m_Position + localMin * m_Scale;
        glm::vec3 wMax = m_Position + localMax * m_Scale;

        // Гарантируем min <= max (на случай отрицательного scale)
        outMin = glm::min(wMin, wMax);
        outMax = glm::max(wMin, wMax);
    }

}