#pragma once
#include <glm/glm.hpp>

#include "Scene/Camera.h"
#include "Scene/Scene.h"

namespace SectorG {

    struct PlayerSettings {
        float WalkSpeed    = 5.0f;
        float RunSpeed     = 8.0f;
        float CrouchSpeed  = 2.5f;
        float JumpForce    = 6.0f;
        float Gravity      = 20.0f;
        float MouseSens    = 0.15f;
        float EyeHeight    = 1.7f;
        float CrouchHeight = 1.0f;
        float PlayerRadius = 0.3f;
        float PlayerHeight = 1.8f;
    };

    class Player {
    public:
        Player();

        void Update(float dt, const Scene& scene);

        const glm::vec3& GetPosition() const { return m_Position; }
        const glm::vec3& GetVelocity() const { return m_Velocity; }
        bool IsGrounded()  const { return m_Grounded; }
        bool IsCrouching() const { return m_Crouching; }
        bool IsNoclip()    const { return m_Noclip; }

        Camera& GetCamera() { return m_Camera; }
        const Camera& GetCamera() const { return m_Camera; }

        PlayerSettings& Settings() { return m_Settings; }

    private:
        void HandleMouseLook();
        void HandleMovement(float dt);
        void HandleGravity(float dt);
        void HandleJump();
        void HandleCrouch();
        void HandleNoclipToggle();
        void UpdateCamera();

        void ResolveCollisions(const Scene& scene);
        bool CheckAABBCollision(const glm::vec3& objMin,
                                const glm::vec3& objMax,
                                glm::vec3& outPushDir,
                                float& outPushDist) const;

        glm::vec3 m_Position           = glm::vec3(0.0f, 0.0f, 5.0f);  // ноги
        glm::vec3 m_Velocity           = glm::vec3(0.0f);              // вертикальная + для noclip
        glm::vec3 m_HorizontalVelocity = glm::vec3(0.0f);              // горизонтальная

        bool  m_Grounded  = false;
        bool  m_Crouching = false;
        bool  m_Noclip    = false;

        float m_CurrentEyeHeight = 1.7f;

        PlayerSettings m_Settings;
        Camera m_Camera;
    };

}