#include "Scene/Light.h"

namespace SectorG {
    // всё inline в заголовке
}