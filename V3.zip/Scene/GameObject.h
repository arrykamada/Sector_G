#pragma once
#include <glm/glm.hpp>
#include <memory>

#include "Render/Mesh.h"

namespace SectorG {

    class GameObject {
    public:
        GameObject() = default;

        GameObject(std::shared_ptr<Mesh> mesh,
                   unsigned int textureID,
                   const glm::vec3& position = glm::vec3(0.0f),
                   const glm::vec3& rotation = glm::vec3(0.0f),
                   const glm::vec3& scale    = glm::vec3(1.0f),
                   const glm::vec3& color    = glm::vec3(1.0f))
            : m_Mesh(mesh),
              m_TextureID(textureID),
              m_Position(position),
              m_Rotation(rotation),
              m_Scale(scale),
              m_Color(color)
        {}

        // --- Getters ---
        std::shared_ptr<Mesh> GetMesh() const { return m_Mesh; }
        unsigned int GetTextureID() const { return m_TextureID; }
        const glm::vec3& GetPosition() const { return m_Position; }
        const glm::vec3& GetRotation() const { return m_Rotation; }
        const glm::vec3& GetScale()    const { return m_Scale; }
        const glm::vec3& GetColor()    const { return m_Color; }

        // --- Setters ---
        void SetPosition(const glm::vec3& p) { m_Position = p; }
        void SetRotation(const glm::vec3& r) { m_Rotation = r; }
        void SetScale(const glm::vec3& s)    { m_Scale = s; }
        void SetColor(const glm::vec3& c)    { m_Color = c; }
        void SetTextureID(unsigned int id)   { m_TextureID = id; }

        // Модельная матрица
        glm::mat4 GetModelMatrix() const;

        // AABB
        void GetAABB(glm::vec3& outMin, glm::vec3& outMax) const;

    private:
        std::shared_ptr<Mesh> m_Mesh;
        unsigned int m_TextureID = 0;

        glm::vec3 m_Position = glm::vec3(0.0f);
        glm::vec3 m_Rotation = glm::vec3(0.0f);
        glm::vec3 m_Scale    = glm::vec3(1.0f);
        glm::vec3 m_Color    = glm::vec3(1.0f);
    };

}