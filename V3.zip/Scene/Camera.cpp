#include "Scene/Camera.h"

#include <glm/gtc/matrix_transform.hpp>
#include <cmath>

namespace SectorG {

    Camera::Camera()
        : m_Position(0.0f, 2.0f, 3.0f),
          m_Front(0.0f, 0.0f, -1.0f),
          m_Up(0.0f, 1.0f, 0.0f),
          m_Right(1.0f, 0.0f, 0.0f),
          m_WorldUp(0.0f, 1.0f, 0.0f),
          m_Yaw(-90.0f),
          m_Pitch(0.0f)
    {
        UpdateVectors();
    }

    void Camera::SetYaw(float yaw) {
        m_Yaw = yaw;
        UpdateVectors();
    }

    void Camera::SetPitch(float pitch) {
        if (pitch >  89.0f) pitch =  89.0f;
        if (pitch < -89.0f) pitch = -89.0f;
        m_Pitch = pitch;
        UpdateVectors();
    }

    void Camera::SetRotation(float yaw, float pitch) {
        m_Yaw = yaw;
        if (pitch >  89.0f) pitch =  89.0f;
        if (pitch < -89.0f) pitch = -89.0f;
        m_Pitch = pitch;
        UpdateVectors();
    }

    void Camera::UpdateVectors() {
        glm::vec3 front;
        front.x = cos(glm::radians(m_Yaw)) * cos(glm::radians(m_Pitch));
        front.y = sin(glm::radians(m_Pitch));
        front.z = sin(glm::radians(m_Yaw)) * cos(glm::radians(m_Pitch));
        m_Front = glm::normalize(front);

        m_Right = glm::normalize(glm::cross(m_Front, m_WorldUp));
        m_Up    = glm::normalize(glm::cross(m_Right, m_Front));
    }

    glm::mat4 Camera::GetViewMatrix() const {
        return glm::lookAt(m_Position, m_Position + m_Front, m_Up);
    }

    glm::mat4 Camera::GetProjectionMatrix(float aspect) const {
        return glm::perspective(glm::radians(45.0f), aspect, 0.1f, 1000.0f);
    }

}