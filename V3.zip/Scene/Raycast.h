#pragma once
#include <glm/glm.hpp>
#include <limits>
#include <cmath>

namespace SectorG {

    struct Ray {
        glm::vec3 origin;
        glm::vec3 dir;      // должен быть нормализован
    };

    struct RayHit {
        bool      hit       = false;
        float     distance  = std::numeric_limits<float>::max();
        glm::vec3 point     {0.0f};
        glm::vec3 normal    {0.0f};
    };

    // Пересечение луча с AABB (slab method).
    // Возвращает hit с нормалью в точке входа.
    inline RayHit RayIntersectAABB(const Ray& ray,
                                   const glm::vec3& aabbMin,
                                   const glm::vec3& aabbMax)
    {
        RayHit result;

        float tmin = 0.0f;
        float tmax = std::numeric_limits<float>::max();

        glm::vec3 normal(0.0f);
        int axis = -1;
        float sign = 0.0f;

        for (int i = 0; i < 3; ++i) {
            float o = ray.origin[i];
            float d = ray.dir[i];
            float mn = aabbMin[i];
            float mx = aabbMax[i];

            if (std::abs(d) < 1e-8f) {
                // Луч параллелен оси — если origin вне slab, пересечения нет
                if (o < mn || o > mx) return result;
            } else {
                float invD = 1.0f / d;
                float t1 = (mn - o) * invD;
                float t2 = (mx - o) * invD;

                float s = -1.0f;
                if (t1 > t2) {
                    std::swap(t1, t2);
                    s = 1.0f;   // вошли с дальней стороны
                }

                if (t1 > tmin) {
                    tmin = t1;
                    axis = i;
                    sign = s;
                }
                if (t2 < tmax) tmax = t2;

                if (tmin > tmax) return result;  // нет пересечения
            }
        }

        if (axis < 0) return result;

        // Нормаль: направлена против луча по оси входа
        normal[axis] = (ray.dir[axis] > 0.0f) ? -1.0f : 1.0f;

        result.hit      = true;
        result.distance = tmin;
        result.point    = ray.origin + ray.dir * tmin;
        result.normal   = normal;
        return result;
    }

}