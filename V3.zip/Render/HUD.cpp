#include "Render/HUD.h"
#include "Utils/Log.h"

#define GLEW_STATIC
#include <GL/glew.h>

#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <cmath>

namespace SectorG {

    // ============================================================
    //  2D-шейдер: просто позиция + цвет, ортогональная проекция
    // ============================================================
    static const char* s_HUDVertexSrc = R"(
        #version 330 core
        layout (location = 0) in vec2 aPos;
        layout (location = 1) in vec4 aColor;

        uniform mat4 uProjection;

        out vec4 vColor;

        void main() {
            vColor = aColor;
            gl_Position = uProjection * vec4(aPos, 0.0, 1.0);
        }
    )";

    static const char* s_HUDFragmentSrc = R"(
        #version 330 core
        in vec4 vColor;
        out vec4 FragColor;

        void main() {
            FragColor = vColor;
        }
    )";

    // ============================================================
    //  Компиляция шейдера (локальные хелперы)
    // ============================================================
    static unsigned int CompileShader(unsigned int type, const char* src) {
        unsigned int id = glCreateShader(type);
        glShaderSource(id, 1, &src, nullptr);
        glCompileShader(id);

        int ok = 0;
        glGetShaderiv(id, GL_COMPILE_STATUS, &ok);
        if (!ok) {
            int len = 0;
            glGetShaderiv(id, GL_INFO_LOG_LENGTH, &len);
            char* msg = new char[len];
            glGetShaderInfoLog(id, len, &len, msg);
            Log::Error(std::string("HUD shader error: ") + msg);
            delete[] msg;
            glDeleteShader(id);
            return 0;
        }
        return id;
    }

    static unsigned int LinkProgram(const char* vs, const char* fs) {
        unsigned int v = CompileShader(GL_VERTEX_SHADER, vs);
        unsigned int f = CompileShader(GL_FRAGMENT_SHADER, fs);
        if (!v || !f) return 0;

        unsigned int p = glCreateProgram();
        glAttachShader(p, v);
        glAttachShader(p, f);
        glLinkProgram(p);

        int ok = 0;
        glGetProgramiv(p, GL_LINK_STATUS, &ok);
        if (!ok) {
            int len = 0;
            glGetProgramiv(p, GL_INFO_LOG_LENGTH, &len);
            char* msg = new char[len];
            glGetProgramInfoLog(p, len, &len, msg);
            Log::Error(std::string("HUD program link error: ") + msg);
            delete[] msg;
            return 0;
        }

        glDeleteShader(v);
        glDeleteShader(f);
        return p;
    }

    // ============================================================
    //  HUD
    // ============================================================
    HUD::HUD()  {}

    HUD::~HUD() {
        if (m_VBO) glDeleteBuffers(1, &m_VBO);
        if (m_VAO) glDeleteVertexArrays(1, &m_VAO);
        if (m_ShaderProgram) glDeleteProgram(m_ShaderProgram);
    }

    void HUD::Init() {
        m_ShaderProgram = LinkProgram(s_HUDVertexSrc, s_HUDFragmentSrc);
        if (!m_ShaderProgram) {
            Log::Error("HUD: failed to create shader program");
            return;
        }

        m_UProjectionLoc = glGetUniformLocation(m_ShaderProgram, "uProjection");

        glGenVertexArrays(1, &m_VAO);
        glBindVertexArray(m_VAO);

        glGenBuffers(1, &m_VBO);
        glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
        glBufferData(GL_ARRAY_BUFFER,
                     sizeof(m_Vertices), nullptr, GL_DYNAMIC_DRAW);

        // Позиция — 2 float
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);

        // Цвет — 4 float
        glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 6 * sizeof(float),
                              (void*)(2 * sizeof(float)));
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);

        Log::Info("HUD initialized");
    }

    void HUD::Begin(int screenW, int screenH) {
        m_ScreenW = screenW;
        m_ScreenH = screenH;
        m_VertexCount = 0;

        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        // Ортографическая проекция: origin — левый верх,
        // Y растёт вниз (как обычно в UI)
        glm::mat4 proj = glm::ortho(0.0f, (float)screenW,
                                    (float)screenH, 0.0f,
                                    -1.0f, 1.0f);

        glUseProgram(m_ShaderProgram);
        glUniformMatrix4fv(m_UProjectionLoc, 1, GL_FALSE, glm::value_ptr(proj));
    }

    void HUD::End() {
        Flush();

        glDisable(GL_BLEND);
        glEnable(GL_DEPTH_TEST);
    }

    void HUD::PushVertex(float x, float y, const glm::vec4& c) {
        int i = m_VertexCount * 6;
        m_Vertices[i + 0] = x;
        m_Vertices[i + 1] = y;
        m_Vertices[i + 2] = c.r;
        m_Vertices[i + 3] = c.g;
        m_Vertices[i + 4] = c.b;
        m_Vertices[i + 5] = c.a;
        m_VertexCount++;
    }

    void HUD::Flush() {
        if (m_VertexCount == 0) return;

        glBindVertexArray(m_VAO);
        glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
        glBufferSubData(GL_ARRAY_BUFFER, 0,
                        m_VertexCount * 6 * sizeof(float),
                        m_Vertices);

        glDrawArrays(GL_TRIANGLES, 0, m_VertexCount);

        glBindVertexArray(0);
        m_VertexCount = 0;
    }

    // ============================================================
    //  Примитивы
    // ============================================================
    void HUD::DrawRect(float x, float y, float w, float h,
                       const glm::vec4& color)
    {
        // 6 вершин (2 треугольника)
        // Проверяем, влезет ли в буфер
        if (m_VertexCount + 6 > 6 * 6) {
            Flush();
        }

        PushVertex(x,     y,     color);
        PushVertex(x + w, y,     color);
        PushVertex(x + w, y + h, color);

        PushVertex(x,     y,     color);
        PushVertex(x + w, y + h, color);
        PushVertex(x,     y + h, color);
    }

    void HUD::DrawLine(float x1, float y1, float x2, float y2,
                       float thickness, const glm::vec4& color)
    {
        // Перпендикуляр к линии
        float dx = x2 - x1;
        float dy = y2 - y1;
        float len = std::sqrt(dx * dx + dy * dy);
        if (len < 0.0001f) return;

        float nx = -dy / len * thickness * 0.5f;
        float ny =  dx / len * thickness * 0.5f;

        if (m_VertexCount + 6 > 6 * 6) Flush();

        // Квад: (x1,y1)+(n), (x2,y2)+(n), (x2,y2)-(n), (x1,y1)-(n)
        PushVertex(x1 + nx, y1 + ny, color);
        PushVertex(x2 + nx, y2 + ny, color);
        PushVertex(x2 - nx, y2 - ny, color);

        PushVertex(x1 + nx, y1 + ny, color);
        PushVertex(x2 - nx, y2 - ny, color);
        PushVertex(x1 - nx, y1 - ny, color);
    }

    // ============================================================
    //  Готовые элементы
    // ============================================================
    void HUD::DrawCrosshair(int screenW, int screenH, const glm::vec4& color) {
        float cx = screenW * 0.5f;
        float cy = screenH * 0.5f;

        float len = 8.0f;        // длина луча
        float gap = 3.0f;        // отступ от центра
        float thick = 1.5f;

        // 4 линии: влево, вправо, вверх, вниз
        DrawLine(cx - gap - len, cy, cx - gap, cy, thick, color);
        DrawLine(cx + gap,       cy, cx + gap + len, cy, thick, color);
        DrawLine(cx, cy - gap - len, cx, cy - gap, thick, color);
        DrawLine(cx, cy + gap,       cx, cy + gap + len, thick, color);
    }

    void HUD::DrawHealthBar(int screenW, int screenH,
                            float health01,
                            const glm::vec4& bgColor,
                            const glm::vec4& fgColor)
    {
        health01 = glm::clamp(health01, 0.0f, 1.0f);

        float margin = 20.0f;
        float barW   = 260.0f;
        float barH   = 22.0f;

        // Правый верхний угол
        float x = (float)screenW - barW - margin;
        float y = margin;

        // Фон
        DrawRect(x - 2, y - 2, barW + 4, barH + 4, glm::vec4(0.0f, 0.0f, 0.0f, 0.6f));
        DrawRect(x, y, barW, barH, bgColor);

        // Заполнение
        DrawRect(x, y, barW * health01, barH, fgColor);

        // Тонкая рамка сверху (светлая полоска для стиля)
        DrawRect(x, y, barW, 2.0f, glm::vec4(1.0f, 1.0f, 1.0f, 0.25f));
    }

}