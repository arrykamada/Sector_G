#include "Render/Mesh.h"
#include "Scene/Terrain.h"

#define GLEW_STATIC
#include <GL/glew.h>

#include <algorithm>
#include <cmath>

namespace SectorG {

    Mesh::Mesh(const std::vector<Vertex>& vertices,
               const std::vector<unsigned int>& indices)
    {
        Upload(vertices, indices);
    }

    Mesh::~Mesh() {
        if (m_EBO) glDeleteBuffers(1, &m_EBO);
        if (m_VBO) glDeleteBuffers(1, &m_VBO);
        if (m_VAO) glDeleteVertexArrays(1, &m_VAO);
    }

    Mesh::Mesh(Mesh&& other) noexcept
        : m_VAO(other.m_VAO),
          m_VBO(other.m_VBO),
          m_EBO(other.m_EBO),
          m_IndexCount(other.m_IndexCount),
          m_LocalMin(other.m_LocalMin),
          m_LocalMax(other.m_LocalMax)
    {
        other.m_VAO = 0;
        other.m_VBO = 0;
        other.m_EBO = 0;
        other.m_IndexCount = 0;
    }

    Mesh& Mesh::operator=(Mesh&& other) noexcept {
        if (this != &other) {
            if (m_EBO) glDeleteBuffers(1, &m_EBO);
            if (m_VBO) glDeleteBuffers(1, &m_VBO);
            if (m_VAO) glDeleteVertexArrays(1, &m_VAO);

            m_VAO = other.m_VAO;
            m_VBO = other.m_VBO;
            m_EBO = other.m_EBO;
            m_IndexCount = other.m_IndexCount;
            m_LocalMin = other.m_LocalMin;
            m_LocalMax = other.m_LocalMax;

            other.m_VAO = 0;
            other.m_VBO = 0;
            other.m_EBO = 0;
            other.m_IndexCount = 0;
        }
        return *this;
    }

    void Mesh::Upload(const std::vector<Vertex>& vertices,
                      const std::vector<unsigned int>& indices)
    {
        m_IndexCount = (unsigned int)indices.size();

        // === Локальный AABB по вершинам ===
        if (!vertices.empty()) {
            m_LocalMin = vertices[0].Position;
            m_LocalMax = vertices[0].Position;

            for (const auto& v : vertices) {
                m_LocalMin.x = std::min(m_LocalMin.x, v.Position.x);
                m_LocalMin.y = std::min(m_LocalMin.y, v.Position.y);
                m_LocalMin.z = std::min(m_LocalMin.z, v.Position.z);

                m_LocalMax.x = std::max(m_LocalMax.x, v.Position.x);
                m_LocalMax.y = std::max(m_LocalMax.y, v.Position.y);
                m_LocalMax.z = std::max(m_LocalMax.z, v.Position.z);
            }
        }

        glGenVertexArrays(1, &m_VAO);
        glBindVertexArray(m_VAO);

        glGenBuffers(1, &m_VBO);
        glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
        glBufferData(GL_ARRAY_BUFFER,
                     vertices.size() * sizeof(Vertex),
                     vertices.data(),
                     GL_STATIC_DRAW);

        glGenBuffers(1, &m_EBO);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                     indices.size() * sizeof(unsigned int),
                     indices.data(),
                     GL_STATIC_DRAW);

        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                              (void*)offsetof(Vertex, Position));
        glEnableVertexAttribArray(0);

        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                              (void*)offsetof(Vertex, Normal));
        glEnableVertexAttribArray(1);

        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                              (void*)offsetof(Vertex, UV));
        glEnableVertexAttribArray(2);
    }

    void Mesh::Draw() const {
        glBindVertexArray(m_VAO);
        glDrawElements(GL_TRIANGLES, m_IndexCount, GL_UNSIGNED_INT, 0);
    }

    // ============================================================
    // CUBE
    // ============================================================

    Mesh Mesh::CreateCube() {
        std::vector<Vertex> vertices = {
            {{-0.5f, -0.5f, -0.5f}, { 0.0f,  0.0f, -1.0f}, {0.0f, 0.0f}},
            {{ 0.5f, -0.5f, -0.5f}, { 0.0f,  0.0f, -1.0f}, {1.0f, 0.0f}},
            {{ 0.5f,  0.5f, -0.5f}, { 0.0f,  0.0f, -1.0f}, {1.0f, 1.0f}},
            {{-0.5f,  0.5f, -0.5f}, { 0.0f,  0.0f, -1.0f}, {0.0f, 1.0f}},
            {{-0.5f, -0.5f,  0.5f}, { 0.0f,  0.0f,  1.0f}, {0.0f, 0.0f}},
            {{ 0.5f, -0.5f,  0.5f}, { 0.0f,  0.0f,  1.0f}, {1.0f, 0.0f}},
            {{ 0.5f,  0.5f,  0.5f}, { 0.0f,  0.0f,  1.0f}, {1.0f, 1.0f}},
            {{-0.5f,  0.5f,  0.5f}, { 0.0f,  0.0f,  1.0f}, {0.0f, 1.0f}},
            {{-0.5f, -0.5f, -0.5f}, {-1.0f,  0.0f,  0.0f}, {0.0f, 0.0f}},
            {{-0.5f, -0.5f,  0.5f}, {-1.0f,  0.0f,  0.0f}, {1.0f, 0.0f}},
            {{-0.5f,  0.5f,  0.5f}, {-1.0f,  0.0f,  0.0f}, {1.0f, 1.0f}},
            {{-0.5f,  0.5f, -0.5f}, {-1.0f,  0.0f,  0.0f}, {0.0f, 1.0f}},
            {{ 0.5f, -0.5f, -0.5f}, { 1.0f,  0.0f,  0.0f}, {0.0f, 0.0f}},
            {{ 0.5f, -0.5f,  0.5f}, { 1.0f,  0.0f,  0.0f}, {1.0f, 0.0f}},
            {{ 0.5f,  0.5f,  0.5f}, { 1.0f,  0.0f,  0.0f}, {1.0f, 1.0f}},
            {{ 0.5f,  0.5f, -0.5f}, { 1.0f,  0.0f,  0.0f}, {0.0f, 1.0f}},
            {{-0.5f, -0.5f, -0.5f}, { 0.0f, -1.0f,  0.0f}, {0.0f, 0.0f}},
            {{ 0.5f, -0.5f, -0.5f}, { 0.0f, -1.0f,  0.0f}, {1.0f, 0.0f}},
            {{ 0.5f, -0.5f,  0.5f}, { 0.0f, -1.0f,  0.0f}, {1.0f, 1.0f}},
            {{-0.5f, -0.5f,  0.5f}, { 0.0f, -1.0f,  0.0f}, {0.0f, 1.0f}},
            {{-0.5f,  0.5f, -0.5f}, { 0.0f,  1.0f,  0.0f}, {0.0f, 0.0f}},
            {{ 0.5f,  0.5f, -0.5f}, { 0.0f,  1.0f,  0.0f}, {1.0f, 0.0f}},
            {{ 0.5f,  0.5f,  0.5f}, { 0.0f,  1.0f,  0.0f}, {1.0f, 1.0f}},
            {{-0.5f,  0.5f,  0.5f}, { 0.0f,  1.0f,  0.0f}, {0.0f, 1.0f}},
        };

        std::vector<unsigned int> indices = {
             0,  1,  2,   2,  3,  0,
             4,  5,  6,   6,  7,  4,
             8,  9, 10,  10, 11,  8,
            12, 13, 14,  14, 15, 12,
            16, 17, 18,  18, 19, 16,
            20, 21, 22,  22, 23, 20,
        };

        return Mesh(vertices, indices);
    }

    // ============================================================
    // FLOOR
    // ============================================================

    Mesh Mesh::CreateFloor(float size) {
        float h = size * 0.5f;

        std::vector<Vertex> vertices = {
            {{-h, 0.0f, -h}, {0.0f, 1.0f, 0.0f}, {0.0f, 0.0f}},
            {{ h, 0.0f, -h}, {0.0f, 1.0f, 0.0f}, {size, 0.0f}},
            {{ h, 0.0f,  h}, {0.0f, 1.0f, 0.0f}, {size, size}},
            {{-h, 0.0f,  h}, {0.0f, 1.0f, 0.0f}, {0.0f, size}},
        };

        std::vector<unsigned int> indices = {
            0, 1, 2,
            2, 3, 0,
        };

        return Mesh(vertices, indices);
    }

    // ============================================================
    // TERRAIN
    // ============================================================

    Mesh Mesh::CreateTerrain(float size, int resolution) {
        std::vector<Vertex> vertices;
        std::vector<unsigned int> indices;

        vertices.reserve((resolution + 1) * (resolution + 1));

        float half = size * 0.5f;
        float step = size / (float)resolution;
        const float tileSize = 4.0f;

        for (int z = 0; z <= resolution; ++z) {
            for (int x = 0; x <= resolution; ++x) {
                float fx = -half + x * step;
                float fz = -half + z * step;
                float fy = TerrainHeight(fx, fz);

                Vertex v;
                v.Position = glm::vec3(fx, fy, fz);
                v.Normal   = glm::vec3(0.0f, 1.0f, 0.0f);
                v.UV       = glm::vec2(fx / tileSize, fz / tileSize);
                vertices.push_back(v);
            }
        }

        for (int z = 0; z < resolution; ++z) {
            for (int x = 0; x < resolution; ++x) {
                int i0 = z * (resolution + 1) + x;
                int i1 = i0 + 1;
                int i2 = i0 + (resolution + 1);
                int i3 = i2 + 1;

                indices.push_back(i0);
                indices.push_back(i2);
                indices.push_back(i1);

                indices.push_back(i1);
                indices.push_back(i2);
                indices.push_back(i3);
            }
        }

        for (int z = 0; z <= resolution; ++z) {
            for (int x = 0; x <= resolution; ++x) {
                int idx = z * (resolution + 1) + x;

                int left  = (x > 0) ? idx - 1 : idx;
                int right = (x < resolution) ? idx + 1 : idx;
                int down  = (z > 0) ? idx - (resolution + 1) : idx;
                int up    = (z < resolution) ? idx + (resolution + 1) : idx;

                glm::vec3 dx = vertices[right].Position - vertices[left].Position;
                glm::vec3 dz = vertices[up].Position - vertices[down].Position;

                glm::vec3 n = glm::cross(dz, dx);
                if (glm::length(n) > 0.0f)
                    n = glm::normalize(n);

                vertices[idx].Normal = n;
            }
        }

        return Mesh(vertices, indices);
    }

    // ============================================================
    // WATER PLANE
    // ============================================================

    Mesh Mesh::CreateWaterPlane(float size, int resolution, float height) {
        std::vector<Vertex> vertices;
        std::vector<unsigned int> indices;

        vertices.reserve((resolution + 1) * (resolution + 1));

        float half = size * 0.5f;
        float step = size / (float)resolution;
        const float tileSize = 8.0f;

        for (int z = 0; z <= resolution; ++z) {
            for (int x = 0; x <= resolution; ++x) {
                float fx = -half + x * step;
                float fz = -half + z * step;

                Vertex v;
                v.Position = glm::vec3(fx, height, fz);
                v.Normal   = glm::vec3(0.0f, 1.0f, 0.0f);
                v.UV       = glm::vec2(fx / tileSize, fz / tileSize);
                vertices.push_back(v);
            }
        }

        for (int z = 0; z < resolution; ++z) {
            for (int x = 0; x < resolution; ++x) {
                int i0 = z * (resolution + 1) + x;
                int i1 = i0 + 1;
                int i2 = i0 + (resolution + 1);
                int i3 = i2 + 1;

                indices.push_back(i0);
                indices.push_back(i2);
                indices.push_back(i1);

                indices.push_back(i1);
                indices.push_back(i2);
                indices.push_back(i3);
            }
        }

        return Mesh(vertices, indices);
    }

}