#include "Render/Skybox.h"
#include "Utils/Log.h"

#define GLEW_STATIC
#include <GL/glew.h>

#include <glm/gtc/type_ptr.hpp>

#include <stb_image.h>

namespace SectorG {

    // --- Шейдеры скайбокса ---

    static const char* s_VertexSrc = R"(
        #version 330 core
        layout (location = 0) in vec3 aPos;

        uniform mat4 uView;
        uniform mat4 uProjection;

        out vec3 vLocalPos;

        void main() {
            vLocalPos = aPos;
            // Убираем трансляцию из view — скайбокс всегда в центре камеры
            mat4 viewNoTranslation = mat4(mat3(uView));
            vec4 pos = uProjection * viewNoTranslation * vec4(aPos, 1.0);
            // z = w — максимальная глубина
            gl_Position = pos.xyww;
        }
    )";

    static const char* s_FragmentSrc = R"(
        #version 330 core
        in vec3 vLocalPos;
        out vec4 FragColor;

        uniform sampler2D uPanorama;

        // Перевод 3D-направления в UV панорамы
        vec2 SampleSphericalMap(vec3 v) {
            vec2 uv = vec2(atan(v.z, v.x), asin(v.y));
            uv *= vec2(0.1591, 0.3183);   // 1/(2π), 1/π
            uv += 0.5;
            return uv;
        }

        void main() {
            vec2 uv = SampleSphericalMap(normalize(vLocalPos));
            // Инвертируем Y, потому что equirectangular обычно в другом порядке
            uv.y = 1.0 - uv.y;
            FragColor = texture(uPanorama, uv);
        }
    )";

    // --- Shader helpers ---
    static unsigned int CompileShader(unsigned int type, const char* src) {
        unsigned int id = glCreateShader(type);
        glShaderSource(id, 1, &src, nullptr);
        glCompileShader(id);

        int result;
        glGetShaderiv(id, GL_COMPILE_STATUS, &result);
        if (!result) {
            int length;
            glGetShaderiv(id, GL_INFO_LOG_LENGTH, &length);
            char* message = new char[length];
            glGetShaderInfoLog(id, length, &length, message);
            Log::Error(std::string("Skybox shader failed: ") + message);
            delete[] message;
            glDeleteShader(id);
            return 0;
        }
        return id;
    }

    static unsigned int CreateShaderProgram(const char* vs, const char* fs) {
        unsigned int vsId = CompileShader(GL_VERTEX_SHADER, vs);
        unsigned int fsId = CompileShader(GL_FRAGMENT_SHADER, fs);

        unsigned int program = glCreateProgram();
        glAttachShader(program, vsId);
        glAttachShader(program, fsId);
        glLinkProgram(program);

        int result;
        glGetProgramiv(program, GL_LINK_STATUS, &result);
        if (!result) {
            int length;
            glGetProgramiv(program, GL_INFO_LOG_LENGTH, &length);
            char* message = new char[length];
            glGetProgramInfoLog(program, length, &length, message);
            Log::Error(std::string("Skybox program failed: ") + message);
            delete[] message;
        }

        glDeleteShader(vsId);
        glDeleteShader(fsId);
        return program;
    }

    // --- Skybox ---

    Skybox::Skybox()  {}

    Skybox::~Skybox() {
        if (m_PanoramaTexture) glDeleteTextures(1, &m_PanoramaTexture);
        if (m_VBO) glDeleteBuffers(1, &m_VBO);
        if (m_VAO) glDeleteVertexArrays(1, &m_VAO);
        if (m_ShaderProgram) glDeleteProgram(m_ShaderProgram);
    }

    bool Skybox::Load(const std::string& panoramaPath) {
        // Вершины куба (36 вершин)
        float vertices[] = {
            // Правая (+X)
             1.0f, -1.0f, -1.0f,   1.0f, -1.0f,  1.0f,   1.0f,  1.0f,  1.0f,
             1.0f,  1.0f,  1.0f,   1.0f,  1.0f, -1.0f,   1.0f, -1.0f, -1.0f,
            // Левая (-X)
            -1.0f, -1.0f,  1.0f,  -1.0f, -1.0f, -1.0f,  -1.0f,  1.0f, -1.0f,
            -1.0f,  1.0f, -1.0f,  -1.0f,  1.0f,  1.0f,  -1.0f, -1.0f,  1.0f,
            // Верхняя (+Y)
            -1.0f,  1.0f, -1.0f,   1.0f,  1.0f, -1.0f,   1.0f,  1.0f,  1.0f,
             1.0f,  1.0f,  1.0f,  -1.0f,  1.0f,  1.0f,  -1.0f,  1.0f, -1.0f,
            // Нижняя (-Y)
            -1.0f, -1.0f, -1.0f,  -1.0f, -1.0f,  1.0f,   1.0f, -1.0f,  1.0f,
             1.0f, -1.0f,  1.0f,   1.0f, -1.0f, -1.0f,  -1.0f, -1.0f, -1.0f,
            // Передняя (+Z)
            -1.0f, -1.0f,  1.0f,   1.0f, -1.0f,  1.0f,   1.0f,  1.0f,  1.0f,
             1.0f,  1.0f,  1.0f,  -1.0f,  1.0f,  1.0f,  -1.0f, -1.0f,  1.0f,
            // Задняя (-Z)
             1.0f, -1.0f, -1.0f,  -1.0f, -1.0f, -1.0f,  -1.0f,  1.0f, -1.0f,
            -1.0f,  1.0f, -1.0f,   1.0f,  1.0f, -1.0f,   1.0f, -1.0f, -1.0f,
        };

        glGenVertexArrays(1, &m_VAO);
        glBindVertexArray(m_VAO);

        glGenBuffers(1, &m_VBO);
        glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);

        // --- Загрузка панорамы (обычная, без sRGB) ---
        glGenTextures(1, &m_PanoramaTexture);
        glBindTexture(GL_TEXTURE_2D, m_PanoramaTexture);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        int width, height, channels;
        stbi_set_flip_vertically_on_load(true);
        unsigned char* data = stbi_load(panoramaPath.c_str(), &width, &height, &channels, 0);
        if (data) {
            GLenum format = (channels == 4) ? GL_RGBA : GL_RGB;
            glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
            Log::Info("Panorama loaded: " + panoramaPath +
                      " (" + std::to_string(width) + "x" + std::to_string(height) + ")");
        } else {
            Log::Error("Failed to load panorama: " + panoramaPath);
        }
        stbi_image_free(data);

        // Шейдер
        m_ShaderProgram = CreateShaderProgram(s_VertexSrc, s_FragmentSrc);
        if (!m_ShaderProgram) return false;

        return true;
    }

    void Skybox::Draw(const glm::mat4& view, const glm::mat4& projection) const {
        glDepthFunc(GL_LEQUAL);

        glUseProgram(m_ShaderProgram);

        glUniformMatrix4fv(glGetUniformLocation(m_ShaderProgram, "uView"),       1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(glGetUniformLocation(m_ShaderProgram, "uProjection"), 1, GL_FALSE, glm::value_ptr(projection));

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, m_PanoramaTexture);
        glUniform1i(glGetUniformLocation(m_ShaderProgram, "uPanorama"), 0);

        glBindVertexArray(m_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        glDepthFunc(GL_LESS);
    }

}