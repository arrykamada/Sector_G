#pragma once
#include <glm/glm.hpp>
#include <memory>

#include "Scene/Scene.h"
#include "Render/Skybox.h"
#include "Render/Mesh.h"

namespace SectorG {

    class Renderer {
    public:
        Renderer();
        ~Renderer();

        Renderer(const Renderer&)            = delete;
        Renderer& operator=(const Renderer&) = delete;

        void Init();
        void BeginFrame();

        void Draw(const glm::mat4& view,
                  const glm::mat4& projection,
                  const glm::vec3& cameraPos,
                  const Scene& scene,
                  float time);

        void DrawWater(const Mesh& waterMesh,
                       const glm::mat4& view,
                       const glm::mat4& projection,
                       const glm::vec3& cameraPos,
                       float time);

        std::unique_ptr<Skybox> m_Skybox;

        static unsigned int LoadTexture(const char* path);

    private:
        static const int MAX_SHADOW_LIGHTS = 2;

        struct ShadowLight {
            glm::mat4 lightSpaceMatrix;
            unsigned int depthMapFBO = 0;
            unsigned int depthMapTex = 0;
            glm::vec3   position;
            glm::vec3   direction;
            int         type;
            float       range;
            float       cosInner;
            float       cosOuter;
            bool        valid = false;
        };

        void InitShadowMaps();
        void RenderDepthMaps(const Scene& scene);
        void CollectShadowLights(const Scene& scene);

        void InitFramebuffer();
        void InitBloomFramebuffers();
        void BindFramebuffer();
        void UnbindFramebuffer();

        void BrightnessPass();
        void BlurPass();
        void CompositeToScreen();

        void DrawObject(const GameObject& obj,
                        const glm::mat4& view,
                        const glm::mat4& projection,
                        const glm::vec3& cameraPos,
                        const Scene& scene);

        void RenderFullscreenQuad();

        unsigned int m_ShaderProgram     = 0;
        unsigned int m_DepthProgram      = 0;
        unsigned int m_WaterProgram      = 0;
        unsigned int m_ScreenProgram     = 0;
        unsigned int m_BrightnessProgram = 0;
        unsigned int m_BlurProgram       = 0;

        int m_ModelLoc = -1;
        int m_ViewLoc  = -1;
        int m_ProjLoc  = -1;

        int m_DModelLoc      = -1;
        int m_DLightSpaceLoc = -1;

        const unsigned int SHADOW_WIDTH  = 2048;
        const unsigned int SHADOW_HEIGHT = 2048;

        ShadowLight m_ShadowLights[MAX_SHADOW_LIGHTS];

        // Main scene FBO
        unsigned int m_SceneFBO      = 0;
        unsigned int m_SceneColorTex = 0;
        unsigned int m_SceneDepthRBO = 0;

        // Brightness FBO (half-res)
        unsigned int m_BrightFBO  = 0;
        unsigned int m_BrightTex  = 0;

        // Blur FBO × 2 (ping-pong)
        unsigned int m_BlurFBO[2] = { 0, 0 };
        unsigned int m_BlurTex[2] = { 0, 0 };

        int m_FBOWidth  = 1280;
        int m_FBOHeight = 720;

        // Fullscreen quad
        unsigned int m_QuadVAO = 0;
        unsigned int m_QuadVBO = 0;
    };

}