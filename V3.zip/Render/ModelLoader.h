#pragma once
#include <string>
#include <vector>
#include <glm/glm.hpp>

namespace SectorG {

    struct MeshData {
        std::vector<glm::vec3> positions;
        std::vector<glm::vec3> normals;
        std::vector<glm::vec2> uvs;

        // Индексы вершин (уже с 0, не с 1 как в .obj)
        // Каждый треугольник — 3 индекса.
        struct Triangle {
            unsigned int v0, v1, v2;
        };
        std::vector<Triangle> triangles;

        bool IsValid() const {
            return !positions.empty() && !triangles.empty();
        }
    };

    class ModelLoader {
    public:
        // Загружает .obj и возвращает готовые вершины + индексы
        // для Mesh(vertices, indices).
        // При ошибке — пустые векторы, в Log::Error пишется причина.
        static bool LoadOBJ(const std::string& path,
                            std::vector<glm::vec3>& outPositions,
                            std::vector<glm::vec3>& outNormals,
                            std::vector<glm::vec2>& outUVs,
                            std::vector<unsigned int>& outIndices);

        // Вспомогательное: склеивает позиции/нормали/UV в единый массив
        // уникальных вершин и возвращает индексы.
        // Использует хэш по (v/vt/vn), чтобы избежать дубликатов.
        static void BuildVertexBuffer(
            const MeshData& data,
            std::vector<glm::vec3>& outPositions,
            std::vector<glm::vec3>& outNormals,
            std::vector<glm::vec2>& outUVs,
            std::vector<unsigned int>& outIndices);
    };

}