#pragma once
#include <string>
#include <glm/glm.hpp>

namespace SectorG {

    class Skybox {
    public:
        Skybox();
        ~Skybox();

        Skybox(const Skybox&)            = delete;
        Skybox& operator=(const Skybox&) = delete;

        // Загрузка одной панорамы 360° (equirectangular)
        bool Load(const std::string& panoramaPath);

        // Рисует скайбокс (view без трансляции, projection)
        void Draw(const glm::mat4& view,
                  const glm::mat4& projection) const;

    private:
        unsigned int m_VAO = 0;
        unsigned int m_VBO = 0;
        unsigned int m_PanoramaTexture = 0;
        unsigned int m_ShaderProgram = 0;
    };

}