#include "Render/ModelLoader.h"
#include "Utils/Log.h"

#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>

namespace SectorG {

    // ============================================================
    //  Ключ уникальной вершины: (position, uv, normal)
    // ============================================================
    struct VertexKey {
        int p = -1;
        int t = -1;
        int n = -1;

        bool operator==(const VertexKey& o) const {
            return p == o.p && t == o.t && n == o.n;
        }
    };

    struct VertexKeyHash {
        size_t operator()(const VertexKey& k) const {
            size_t h = 2166136261u;
            h = (h ^ (size_t)(k.p + 1)) * 16777619u;
            h = (h ^ (size_t)(k.t + 1)) * 16777619u;
            h = (h ^ (size_t)(k.n + 1)) * 16777619u;
            return h;
        }
    };

    // ============================================================
    //  Парсинг одной вершины грани: "v", "v/vt", "v//vn", "v/vt/vn"
    //  Возвращает три индекса с 0-базой (или -1 если не задано).
    // ============================================================
    static bool ParseFaceVertex(const std::string& token,
                                int& outP, int& outT, int& outN)
    {
        outP = outT = outN = -1;

        size_t s1 = token.find('/');
        if (s1 == std::string::npos) {
            outP = std::stoi(token) - 1;
            return outP >= 0;
        }

        size_t s2 = token.find('/', s1 + 1);
        if (s2 == std::string::npos) {
            outP = std::stoi(token.substr(0, s1)) - 1;
            outT = std::stoi(token.substr(s1 + 1)) - 1;
            return outP >= 0;
        }

        outP = std::stoi(token.substr(0, s1)) - 1;
        if (s2 > s1 + 1) {
            outT = std::stoi(token.substr(s1 + 1, s2 - s1 - 1)) - 1;
        }
        outN = std::stoi(token.substr(s2 + 1)) - 1;

        return outP >= 0;
    }

    // ============================================================
    //  LoadOBJ
    // ============================================================
    bool ModelLoader::LoadOBJ(const std::string& path,
                              std::vector<glm::vec3>& outPositions,
                              std::vector<glm::vec3>& outNormals,
                              std::vector<glm::vec2>& outUVs,
                              std::vector<unsigned int>& outIndices)
    {
        outPositions.clear();
        outNormals.clear();
        outUVs.clear();
        outIndices.clear();

        std::ifstream file(path);
        if (!file.is_open()) {
            Log::Error("ModelLoader: cannot open " + path);
            return false;
        }

        // Временные массивы из .obj
        std::vector<glm::vec3> positions;
        std::vector<glm::vec3> normals;
        std::vector<glm::vec2> uvs;

        // Уникальные вершины итогового меша
        std::unordered_map<VertexKey, unsigned int, VertexKeyHash> unique;

        std::string line;
        int lineNum = 0;
        int triCount = 0;

        while (std::getline(file, line)) {
            ++lineNum;
            if (line.empty() || line[0] == '#') continue;

            std::istringstream ss(line);
            std::string tag;
            ss >> tag;

            if (tag == "v") {
                glm::vec3 p;
                ss >> p.x >> p.y >> p.z;
                positions.push_back(p);
            }
            else if (tag == "vn") {
                glm::vec3 n;
                ss >> n.x >> n.y >> n.z;
                normals.push_back(n);
            }
            else if (tag == "vt") {
                glm::vec2 uv;
                ss >> uv.x >> uv.y;
                uvs.push_back(uv);
            }
            else if (tag == "f") {
                // Собираем все вершины полигона
                std::vector<VertexKey> poly;
                std::string token;
                while (ss >> token) {
                    VertexKey k;
                    if (!ParseFaceVertex(token, k.p, k.t, k.n)) {
                        Log::Error("ModelLoader: bad face token '" + token +
                                   "' at line " + std::to_string(lineNum));
                        continue;
                    }
                    poly.push_back(k);
                }

                if (poly.size() < 3) continue;

                // Триангуляция веером: (0, i, i+1)
                for (size_t i = 1; i + 1 < poly.size(); ++i) {
                    VertexKey tri[3] = { poly[0], poly[i], poly[i + 1] };

                    for (int c = 0; c < 3; ++c) {
                        const VertexKey& key = tri[c];

                        auto it = unique.find(key);
                        unsigned int index;

                        if (it != unique.end()) {
                            index = it->second;
                        } else {
                            index = (unsigned int)outPositions.size();

                            // Позиция
                            glm::vec3 p(0.0f);
                            if (key.p >= 0 && key.p < (int)positions.size())
                                p = positions[key.p];

                            // Нормаль
                            glm::vec3 n(0.0f, 1.0f, 0.0f);
                            if (key.n >= 0 && key.n < (int)normals.size())
                                n = normals[key.n];

                            // UV
                            glm::vec2 uv(0.0f);
                            if (key.t >= 0 && key.t < (int)uvs.size())
                                uv = uvs[key.t];

                            outPositions.push_back(p);
                            outNormals.push_back(n);
                            outUVs.push_back(uv);

                            unique.emplace(key, index);
                        }

                        outIndices.push_back(index);
                    }

                    ++triCount;
                }
            }
        }

        if (outPositions.empty() || outIndices.empty()) {
            Log::Error("ModelLoader: empty mesh in " + path);
            return false;
        }

        Log::Info("ModelLoader: loaded " + path +
                  " (" + std::to_string(outPositions.size()) + " verts, " +
                  std::to_string(triCount) + " tris)");
        return true;
    }

    // ============================================================
    //  BuildVertexBuffer — на случай, если понадобится отдельно
    // ============================================================
    void ModelLoader::BuildVertexBuffer(
        const MeshData& data,
        std::vector<glm::vec3>& outPositions,
        std::vector<glm::vec3>& outNormals,
        std::vector<glm::vec2>& outUVs,
        std::vector<unsigned int>& outIndices)
    {
        // Пока не используется (всё уже внутри LoadOBJ).
        (void)data;
        (void)outPositions;
        (void)outNormals;
        (void)outUVs;
        (void)outIndices;
    }

}