#pragma once
#include <glm/glm.hpp>

namespace SectorG {

    class HUD {
    public:
        HUD();
        ~HUD();

        // Инициализация: создать шейдер, VAO, VBO
        void Init();

        // Вызывать каждый кадр после отрисовки 3D-сцены.
        // screenW / screenH — размеры окна в пикселях.
        void Begin(int screenW, int screenH);
        void End();

        // Примитивы (координаты в пикселях, origin — левый верх)
        void DrawRect(float x, float y, float w, float h,
                      const glm::vec4& color);

        void DrawLine(float x1, float y1, float x2, float y2,
                      float thickness, const glm::vec4& color);

        // Готовые элементы
        void DrawCrosshair(int screenW, int screenH,
                           const glm::vec4& color = glm::vec4(1.0f));

        void DrawHealthBar(int screenW, int screenH,
                           float health01,
                           const glm::vec4& bgColor  = glm::vec4(0.1f, 0.1f, 0.1f, 0.7f),
                           const glm::vec4& fgColor  = glm::vec4(0.8f, 0.1f, 0.1f, 1.0f));

    private:
        unsigned int m_ShaderProgram = 0;
        unsigned int m_VAO = 0;
        unsigned int m_VBO = 0;

        int m_ScreenW = 0;
        int m_ScreenH = 0;

        // Временный буфер вершин для батчинга (x,y,r,g,b,a)
        float m_Vertices[6 * 6 * 6]; // 6 квадов по 6 вершин по 6 float
        int   m_VertexCount = 0;

        void Flush();

        // Униформы
        int m_UProjectionLoc = -1;

        void PushVertex(float x, float y, const glm::vec4& c);
    };

}