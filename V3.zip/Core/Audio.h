#pragma once
#include <string>

namespace SectorG {

    class Audio {
    public:
        static bool Init();
        static void Shutdown();

        // Фоновый звук (ambient) — играет по кругу
        static bool PlayBackground(const std::string& path, float volume = 0.5f);
        static void StopBackground();

        static void SetBackgroundVolume(float volume);

    private:
        static bool s_Initialized;
    };

}