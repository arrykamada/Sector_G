#pragma once
#include <memory>

#include "Core/Window.h"
#include "Core/Audio.h"
#include "Render/Renderer.h"
#include "Render/Mesh.h"
#include "Render/HUD.h"
#include "Scene/Scene.h"
#include "Scene/Player.h"

namespace SectorG {

    class Application {
    public:
        Application();
        ~Application();

        void Run();

        float GetHealth() const { return m_Health; }
        void  SetHealth(float h) { m_Health = h; }

    private:
        void SetupScene();

        std::unique_ptr<Window>   m_Window;
        std::unique_ptr<Renderer> m_Renderer;
        std::unique_ptr<Player>   m_Player;
        std::unique_ptr<HUD>      m_HUD;

        std::shared_ptr<Mesh> m_TerrainMesh;
        std::shared_ptr<Mesh> m_WaterMesh;

        Scene m_Scene;

        bool  m_Running = true;
        float m_Health  = 1.0f;   // 0..1
    };

}