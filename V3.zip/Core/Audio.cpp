#include "Core/Audio.h"
#include "Utils/Log.h"

#include <miniaudio.h>

namespace SectorG {

    static ma_engine s_Engine;
    static ma_sound s_BackgroundSound;
    static bool     s_BackgroundLoaded = false;

    bool Audio::s_Initialized = false;

    bool Audio::Init() {
        if (s_Initialized) return true;

        ma_result result = ma_engine_init(NULL, &s_Engine);
        if (result != MA_SUCCESS) {
            Log::Error("Failed to initialize audio engine");
            return false;
        }

        s_Initialized = true;
        Log::Info("Audio engine initialized");
        return true;
    }

    void Audio::Shutdown() {
        if (s_BackgroundLoaded) {
            ma_sound_uninit(&s_BackgroundSound);
            s_BackgroundLoaded = false;
        }

        if (s_Initialized) {
            ma_engine_uninit(&s_Engine);
            s_Initialized = false;
            Log::Info("Audio engine shutdown");
        }
    }

    bool Audio::PlayBackground(const std::string& path, float volume) {
        if (!s_Initialized) {
            Log::Error("Audio not initialized");
            return false;
        }

        if (s_BackgroundLoaded) {
            ma_sound_uninit(&s_BackgroundSound);
            s_BackgroundLoaded = false;
        }

        ma_result result = ma_sound_init_from_file(
            &s_Engine, path.c_str(),
            MA_SOUND_FLAG_STREAM,   // стриминг для длинных файлов
            NULL, NULL,
            &s_BackgroundSound
        );

        if (result != MA_SUCCESS) {
            Log::Error("Failed to load background sound: " + path);
            return false;
        }

        ma_sound_set_looping(&s_BackgroundSound, MA_TRUE);
        ma_sound_set_volume(&s_BackgroundSound, volume);
        ma_sound_start(&s_BackgroundSound);

        s_BackgroundLoaded = true;
        Log::Info("Background sound started: " + path);
        return true;
    }

    void Audio::StopBackground() {
        if (s_BackgroundLoaded) {
            ma_sound_stop(&s_BackgroundSound);
            ma_sound_uninit(&s_BackgroundSound);
            s_BackgroundLoaded = false;
        }
    }

    void Audio::SetBackgroundVolume(float volume) {
        if (s_BackgroundLoaded) {
            ma_sound_set_volume(&s_BackgroundSound, volume);
        }
    }

}