#include "Core/Application.h"
#include "Core/Input.h"
#include "Utils/Log.h"
#include "Scene/Terrain.h"
#include "Scene/Raycast.h"
#include "Render/ModelLoader.h"

#include <cmath>

namespace SectorG {

    // ============================================================
    //  Загрузка .obj → shared_ptr<Mesh>
    // ============================================================
    static std::shared_ptr<Mesh> LoadMeshFromOBJ(const std::string& path) {
        std::vector<glm::vec3> positions;
        std::vector<glm::vec3> normals;
        std::vector<glm::vec2> uvs;
        std::vector<unsigned int> indices;

        if (!ModelLoader::LoadOBJ(path, positions, normals, uvs, indices))
            return nullptr;

        std::vector<Vertex> verts;
        verts.reserve(positions.size());

        for (size_t i = 0; i < positions.size(); ++i) {
            Vertex v;
            v.Position = positions[i];
            v.Normal   = (i < normals.size()) ? normals[i] : glm::vec3(0.0f, 1.0f, 0.0f);
            v.UV       = (i < uvs.size())     ? uvs[i]     : glm::vec2(0.0f);
            verts.push_back(v);
        }

        return std::make_shared<Mesh>(verts, indices);
    }

    // ============================================================
    //  Авто-посадка объекта на землю
    // ============================================================
    static glm::vec3 PlaceOnGround(const std::shared_ptr<Mesh>& mesh,
                                   float x, float z,
                                   float scale = 1.0f,
                                   float yOffset = 0.0f)
    {
        float terrainY = TerrainHeight(x, z);

        if (!mesh) return glm::vec3(x, terrainY + yOffset, z);

        float localMinY = mesh->GetLocalMin().y;
        float worldMinY = localMinY * scale;

        float finalY = terrainY - worldMinY + yOffset;
        return glm::vec3(x, finalY, z);
    }

    Application::Application() {
        Log::Info("Application created");

        Audio::Init();

        m_Window = std::make_unique<Window>(WindowProps{
            "Sector_G", 1280, 720
        });

        m_Renderer = std::make_unique<Renderer>();
        m_Renderer->Init();

        m_Renderer->m_Skybox = std::make_unique<Skybox>();
        m_Renderer->m_Skybox->Load("assets/s.png");

        // === HUD ===
        m_HUD = std::make_unique<HUD>();
        m_HUD->Init();

        m_Player = std::make_unique<Player>();
        m_Player->Settings().WalkSpeed = 20.0f;
        m_Player->Settings().RunSpeed  = 35.0f;
        m_Player->Settings().JumpForce = 10.0f;
        m_Player->Settings().Gravity   = 22.0f;

        SetupScene();

        Audio::PlayBackground("assets/sounds/sarah.wav", 0.4f);
    }

    Application::~Application() {
        Audio::Shutdown();
        Log::Info("Application destroyed");
    }

    void Application::SetupScene() {
        Log::Info("Setting up scene...");

        m_TerrainMesh = std::make_shared<Mesh>(Mesh::CreateTerrain(240.0f, 256));
        m_WaterMesh   = std::make_shared<Mesh>(Mesh::CreateWaterPlane(240.0f, 128, WATER_LEVEL));

        unsigned int grassTex = Renderer::LoadTexture("assets/test.jpg");

        m_Scene.Add(GameObject(
            m_TerrainMesh,
            grassTex,
            glm::vec3(0.0f, 0.0f, 0.0f),
            glm::vec3(0.0f),
            glm::vec3(1.0f),
            glm::vec3(1.0f)
        ));

        // ============================================================
        // ТЕСТОВЫЕ КУБЫ — стоят на земле
        // ============================================================
        auto cubeMesh = std::make_shared<Mesh>(Mesh::CreateCube());

        m_Scene.Add(GameObject(
            cubeMesh, grassTex,
            PlaceOnGround(cubeMesh,  8.0f,  0.0f, 2.0f),
            glm::vec3(0.0f),
            glm::vec3(2.0f),
            glm::vec3(1.0f)
        ));

        m_Scene.Add(GameObject(
            cubeMesh, grassTex,
            PlaceOnGround(cubeMesh, -6.0f,  4.0f, 2.0f),
            glm::vec3(0.0f, 45.0f, 0.0f),
            glm::vec3(2.0f),
            glm::vec3(1.0f)
        ));

        m_Scene.Add(GameObject(
            cubeMesh, grassTex,
            PlaceOnGround(cubeMesh,  2.0f, -8.0f, 3.0f),
            glm::vec3(0.0f),
            glm::vec3(3.0f, 1.0f, 3.0f),
            glm::vec3(1.0f)
        ));

        // ============================================================
        // ТЕСТОВАЯ .OBJ МОДЕЛЬ — дом на земле
        // ============================================================
        auto modelMesh = LoadMeshFromOBJ("assets/models/house.obj");
        if (modelMesh) {
            Log::Info("House mesh AABB: min=(" +
                std::to_string(modelMesh->GetLocalMin().x) + ", " +
                std::to_string(modelMesh->GetLocalMin().y) + ", " +
                std::to_string(modelMesh->GetLocalMin().z) + ") max=(" +
                std::to_string(modelMesh->GetLocalMax().x) + ", " +
                std::to_string(modelMesh->GetLocalMax().y) + ", " +
                std::to_string(modelMesh->GetLocalMax().z) + ")");

            unsigned int modelTex = Renderer::LoadTexture("assets/test.jpg");

            float houseScale = 3.0f;
            float houseX     = 15.0f;
            float houseZ     = -15.0f;

            glm::vec3 housePos = PlaceOnGround(modelMesh, houseX, houseZ, houseScale);

            m_Scene.Add(GameObject(
                modelMesh, modelTex,
                housePos,
                glm::vec3(0.0f),
                glm::vec3(houseScale),
                glm::vec3(1.0f)
            ));

            Log::Info("House placed at y=" + std::to_string(housePos.y) +
                      " scale=" + std::to_string(houseScale));
        } else {
            Log::Info("No .obj model found at assets/models/house.obj (skipping)");
        }

        // ============================================================
        // СВЕТ
        // ============================================================
        m_Scene.AddLight(Light::CreatePoint(
            glm::vec3(3.0f, 12.0f, 3.0f),
            glm::vec3(1.0f, 0.95f, 0.85f),
            1.0f,
            40.0f
        ));

        m_Scene.AddLight(Light::CreatePoint(
            glm::vec3(-10.0f, 6.0f, -10.0f),
            glm::vec3(0.25f, 0.35f, 0.6f),
            0.6f,
            35.0f
        ));

        m_Scene.AddLight(Light::CreateDirectional(
            glm::vec3(0.3f, -0.8f, -0.5f),
            glm::vec3(0.7f, 0.7f, 0.75f),
            1.3f
        ));

        m_Scene.AddLight(Light::CreateSpot(
            glm::vec3(0.0f, 20.0f, 0.0f),
            glm::vec3(0.0f, -1.0f, 0.0f),
            glm::vec3(1.0f, 0.5f, 0.3f),
            1.5f, 40.0f, 25.0f, 35.0f
        ));

        Log::Info("Scene has " + std::to_string(m_Scene.Size()) + " objects and " +
                  std::to_string(m_Scene.GetLights().size()) + " lights");
    }

    void Application::Run() {
        Log::Info("Main loop started");

        float time = 0.0f;
        float dt   = 0.016f;

        float rayLogTimer = 0.0f;

        while (m_Running && !m_Window->ShouldClose()) {
            time += dt;

            auto& lights = m_Scene.GetLightsMutable();
            if (!lights.empty()) {
                float radius = 10.0f;
                float speed  = 0.6f;
                float height = 10.0f + std::sin(time * 0.5f) * 2.0f;

                float angle = time * speed;
                lights[0].SetPosition(glm::vec3(
                    std::cos(angle) * radius,
                    height,
                    std::sin(angle) * radius
                ));
            }

            m_Player->Update(dt, m_Scene);

            const Camera& cam = m_Player->GetCamera();

            // ============================================================
            // ТЕСТ RAYCAST (раз в 0.5 сек)
            // ============================================================
            {
                glm::vec3 rayOrigin = cam.GetPosition();
                glm::vec3 rayDir    = cam.GetFront();

                const GameObject* hitObj = nullptr;
                RayHit hit = m_Scene.Raycast(rayOrigin, rayDir, 300.0f, &hitObj);

                rayLogTimer += dt;
                if (rayLogTimer > 0.5f) {
                    rayLogTimer = 0.0f;
                    if (hit.hit) {
                        Log::Info("Raycast HIT: point=(" +
                            std::to_string(hit.point.x) + ", " +
                            std::to_string(hit.point.y) + ", " +
                            std::to_string(hit.point.z) + ") dist=" +
                            std::to_string(hit.distance) +
                            " obj=" + (hitObj ? "yes" : "no"));
                    } else {
                        Log::Info("Raycast: no hit");
                    }
                }
            }

            float aspect = (float)m_Window->GetWidth() / (float)m_Window->GetHeight();
            glm::mat4 view       = cam.GetViewMatrix();
            glm::mat4 projection = cam.GetProjectionMatrix(aspect);

            m_Renderer->BeginFrame();

            m_Renderer->Draw(view, projection, cam.GetPosition(), m_Scene, time);
            m_Renderer->DrawWater(*m_WaterMesh, view, projection, cam.GetPosition(), time);

            // ============================================================
            // HUD
            // ============================================================
            int w = m_Window->GetWidth();
            int h = m_Window->GetHeight();

            m_HUD->Begin(w, h);
            m_HUD->DrawCrosshair(w, h);
            m_HUD->DrawHealthBar(w, h, m_Health);
            m_HUD->End();

            m_Window->OnUpdate();
        }

        Log::Info("Main loop stopped");
    }

}